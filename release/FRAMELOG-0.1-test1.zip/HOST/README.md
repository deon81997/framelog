# serial-bench

Host-side tools for [FRAMELOG](https://github.com/deon81997/framelog): frame-time logging for DOS and
Windows 98 games over serial to a second PC. Protocol: framelog/docs/PROTOCOL.md.

Needs Python 3 + `pip install pyserial matplotlib`.

| Tool | What |
|---|---|
| `fllog.py PORT -o run.csv [--label NAME] [--idle S] [--seconds N]` | logger: sends S (start), writes frames to CSV, X (stop) on Ctrl+C. PORT = COM3, /dev/ttyUSB0, or a pyserial URL (socket://127.0.0.1:4555 for QEMU) |
| `flstats.py a.csv [b.csv ...] [--png g.png] [--skip S]` | stats per run (avg fps, min/max frame time, 1% / 0.1% lows = fps at the 99th / 99.9th percentile frame time) + frame-time graph; several files = machine comparison |
| `flproto.py` | protocol encoder/decoder (resyncs on noise) |

Tests: `python3 -m unittest discover -s tests`.

Typical run: game PC `FRAMELOG /COM:1` in AUTOEXEC (after HDPMI32I / SC55); host
`python3 fllog.py COM3 -o duke-d810.csv --label D810`; start the game; Ctrl+C when done;
`python3 flstats.py duke-d810.csv duke-p5pe.csv --png duke.png`.

Later: OpenCV analyzer for Datapath VGA capture (frame changes, tear lines) merged with the serial timeline.
