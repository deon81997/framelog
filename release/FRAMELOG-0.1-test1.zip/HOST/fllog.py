#!/usr/bin/env python3
"""fllog.py - FRAMELOG host logger: COM port (or any pyserial URL, e.g. socket://127.0.0.1:4555 for QEMU) -> CSV.

  fllog.py PORT -o run.csv [--baud 115200] [--seconds N] [--idle S] [--label NAME]

Sends 'S' (start) until the game PC answers with a header, logs frames, and on Ctrl+C / --seconds / --idle
(no frame for S seconds after the first one) sends 'X' (stop). The DOS TSR acts on S/X at the game's next page
flip, so start this before the game or while it runs.
CSV: comment lines (# key=value: label, source, tsc_hz, ...), frame,t_ms,frametime_ms rows (written as they come),\nclosing comments (frames, lost, junk, stop=marker|host; 'host' is normal for DOS: the TSR sees the stop byte\nat the game's next flip)."""
import argparse
import sys
import time

import serial

from flproto import Decoder, Timeline, SOURCES


class CsvOut:
    """streams frames to the CSV as they arrive (a crash or a pulled cable keeps what was logged)"""

    def __init__(self, path, label):
        self.f = open(path, 'w')
        self.f.write(f"# label={label}\n")
        self.hz = None
        self.rows = 0

    def header(self, h):
        self.hz = h['tsc_hz'] or 1
        self.f.write(f"# source={SOURCES.get(h['source'], h['source'])}\n# tsc_hz={self.hz}\n# modes={h['modes']}\n")
        self.f.write("frame,t_ms,frametime_ms\n")

    def frame(self, n, t, d):
        if self.hz:
            self.f.write(f"{n},{t * 1000.0 / self.hz:.4f},{d * 1000.0 / self.hz:.4f}\n")
            self.rows += 1
            if self.rows % 64 == 0:
                self.f.flush()

    def close(self, tl, junk):
        self.f.write(f"# frames={len(tl.frames)}\n# lost={tl.lost}\n# junk={junk}\n")
        if tl.ended:
            self.f.write(f"# stop=marker\n# end_frames={tl.ended['frames']}\n# end_lost={tl.ended['lost']}\n")
        else:   # normal for DOS: the TSR reads the stop byte at the game's next page flip
            self.f.write("# stop=host\n")
        self.f.close()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('port')
    ap.add_argument('-o', '--out', required=True)
    ap.add_argument('--baud', type=int, default=115200)
    ap.add_argument('--seconds', type=float, default=0, help='stop after this long (0 = until Ctrl+C)')
    ap.add_argument('--idle', type=float, default=0, help='stop when no frame came for this long (after the first)')
    ap.add_argument('--label', default='')
    ap.add_argument('-q', '--quiet', action='store_true')
    a = ap.parse_args()

    ser = serial.serial_for_url(a.port, baudrate=a.baud, timeout=0.05)
    dec, tl = Decoder(), Timeline()
    out = CsvOut(a.out, a.label)
    t0 = time.time()
    orphan = 0           # frames before any header: the game PC was still logging from an earlier session
    last_s = last_frame = 0.0
    started = False
    try:
        while True:
            now = time.time()
            if not started and now - last_s > 0.25:
                ser.write(b'S')
                last_s = now
            for kind, r in dec.feed(ser.read(4096)):
                tl.add(kind, r)
                if kind in 'FG' and not started:
                    orphan += 1
                    if orphan == 1:
                        ser.write(b'XS')    # stop the old log, start ours
                    continue
                if kind == 'H':
                    started = True
                    out.header(r)
                    if not a.quiet:
                        print(f"header: {SOURCES.get(r['source'], r['source'])}, TSC {r['tsc_hz'] / 1e6:.2f} MHz", file=sys.stderr)
                if kind in 'FG':
                    last_frame = now
                    out.frame(*tl.frames[-1][:3])
            if a.seconds and now - t0 > a.seconds:
                break
            if a.idle and last_frame and now - last_frame > a.idle:
                break
    except KeyboardInterrupt:
        pass
    except serial.SerialException as e:     # port gone (USB adapter pulled, QEMU quit)
        print(f"port closed: {e}", file=sys.stderr)
    try:
        ser.write(b'X')
        end = time.time() + 0.5
        while time.time() < end and tl.ended is None:
            for kind, r in dec.feed(ser.read(4096)):
                tl.add(kind, r)
                if kind in 'FG' and started:
                    out.frame(*tl.frames[-1][:3])
        ser.close()
    except serial.SerialException:
        pass
    out.close(tl, dec.junk)
    if not a.quiet:
        print(f"{len(tl.frames)} frames, {tl.lost} lost, {dec.junk} junk bytes -> {a.out}", file=sys.stderr)
    return 0 if tl.frames else 1


if __name__ == '__main__':
    sys.exit(main())
