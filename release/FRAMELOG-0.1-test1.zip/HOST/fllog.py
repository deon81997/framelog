#!/usr/bin/env python3
"""fllog.py - FRAMELOG host logger: COM port (or any pyserial URL, e.g. socket://127.0.0.1:4555 for QEMU) -> CSV.

  fllog.py PORT -o run.csv [--baud 115200] [--seconds N] [--idle S] [--label NAME]

Sends 'S' (start) until the game PC answers with a header, logs frames, and on Ctrl+C / --seconds / --idle
(no frame for S seconds after the first one) sends 'X' (stop). The DOS TSR acts on S/X at the game's next page
flip, so start this before the game or while it runs.
CSV: comment lines (# key=value: label, source, tsc_hz, frames, lost, junk), then frame,t_ms,frametime_ms."""
import argparse
import sys
import time

import serial

from flproto import Decoder, Timeline, SOURCES


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('port')
    ap.add_argument('-o', '--out', required=True)
    ap.add_argument('--baud', type=int, default=115200)
    ap.add_argument('--seconds', type=float, default=0, help='stop after this long (0 = until Ctrl+C)')
    ap.add_argument('--idle', type=float, default=0, help='stop when no frame came for this long (after the first)')
    ap.add_argument('--label', default='')
    ap.add_argument('-q', '--quiet', action='store_true')
    a = ap.parse_args()

    ser = serial.serial_for_url(a.port, baudrate=a.baud, timeout=0.05)
    dec, tl = Decoder(), Timeline()
    t0 = time.time()
    last_s = last_frame = 0.0
    started = False
    try:
        while True:
            now = time.time()
            if not started and now - last_s > 0.25:
                ser.write(b'S')
                last_s = now
            for kind, r in dec.feed(ser.read(4096)):
                tl.add(kind, r)
                if kind == 'H':
                    started = True
                    if not a.quiet:
                        print(f"header: {SOURCES.get(r['source'], r['source'])}, TSC {r['tsc_hz'] / 1e6:.2f} MHz", file=sys.stderr)
                if kind in 'FG':
                    last_frame = now
            if a.seconds and now - t0 > a.seconds:
                break
            if a.idle and last_frame and now - last_frame > a.idle:
                break
    except KeyboardInterrupt:
        pass
    except serial.SerialException as e:     # port gone (USB adapter pulled, QEMU quit)
        print(f"port closed: {e}", file=sys.stderr)
    try:
        ser.write(b'X')
        end = time.time() + 0.5
        while time.time() < end and tl.ended is None:
            for kind, r in dec.feed(ser.read(4096)):
                tl.add(kind, r)
        ser.close()
    except serial.SerialException:
        pass
    write_csv(a.out, tl, a.label, dec.junk)
    if not a.quiet:
        print(f"{len(tl.frames)} frames, {tl.lost} lost, {dec.junk} junk bytes -> {a.out}", file=sys.stderr)
    return 0 if tl.frames else 1


def write_csv(path, tl, label, junk):
    hz = tl.tsc_hz or 1
    with open(path, 'w') as f:
        f.write(f"# label={label}\n")
        if tl.header:
            f.write(f"# source={SOURCES.get(tl.header['source'], tl.header['source'])}\n# tsc_hz={hz}\n# modes={tl.header['modes']}\n")
        f.write(f"# frames={len(tl.frames)}\n# lost={tl.lost}\n# junk={junk}\n")
        if tl.ended:
            f.write(f"# end_frames={tl.ended['frames']}\n# end_lost={tl.ended['lost']}\n")
        f.write("frame,t_ms,frametime_ms\n")
        for n, t, d, _ in tl.frames:
            f.write(f"{n},{t * 1000.0 / hz:.4f},{d * 1000.0 / hz:.4f}\n")


if __name__ == '__main__':
    sys.exit(main())
