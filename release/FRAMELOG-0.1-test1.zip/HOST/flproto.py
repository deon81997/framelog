"""FRAMELOG serial protocol v1 (framelog/docs/PROTOCOL.md): encoder + resyncing stream decoder."""
import struct

SYNC = 0xA5
# type -> (payload size, struct format, field names)
TYPES = {
    ord('H'): (8, '<BBIBB', ('ver', 'source', 'tsc_hz', 'modes', 'reserved')),
    ord('B'): (8, '<Q', ('tsc',)),
    ord('F'): (6, '<HI', ('frame', 'delta')),
    ord('G'): (10, '<HQ', ('frame', 'delta')),
    ord('D'): (4, '<I', ('count',)),
    ord('E'): (8, '<II', ('frames', 'lost')),
}
SOURCES = {0: 'DOS', 1: 'Win98'}


def encode(kind, **fields):
    t = ord(kind)
    size, fmt, names = TYPES[t]
    payload = struct.pack(fmt, *(fields.get(n, 0) for n in names))
    return bytes([SYNC, t]) + payload + bytes([(t + sum(payload)) & 0xFF])


def encode_frame(frame, delta):
    """F record, or G when the delta needs more than 32 bits."""
    if delta >> 32:
        return encode('G', frame=frame & 0xFFFF, delta=delta)
    return encode('F', frame=frame & 0xFFFF, delta=delta)


class Decoder:
    """feed(bytes) -> list of (kind, dict). Bad checksums and junk are skipped (counted in .junk)."""

    def __init__(self):
        self.buf = bytearray()
        self.junk = 0

    def feed(self, data):
        self.buf += data
        out = []
        b = self.buf
        i = 0
        while True:
            j = b.find(SYNC, i)
            if j < 0:
                self.junk += len(b) - i
                i = len(b)
                break
            self.junk += j - i
            i = j
            if i + 2 > len(b):
                break
            t = b[i + 1]
            if t not in TYPES:
                self.junk += 1
                i += 1
                continue
            size, fmt, names = TYPES[t]
            if i + 3 + size > len(b):
                break
            payload = bytes(b[i + 2:i + 2 + size])
            if (t + sum(payload)) & 0xFF != b[i + 2 + size]:
                self.junk += 1
                i += 1
                continue
            out.append((chr(t), dict(zip(names, struct.unpack(fmt, payload)))))
            i += 3 + size
        del b[:i]
        return out


class Timeline:
    """Turns decoded records into frames: list of (frame_no, t_ticks since B, delta_ticks)."""

    def __init__(self):
        self.header = None
        self.frames = []
        self.lost = 0
        self.ended = None
        self.t = 0
        self.n = 0

    def add(self, kind, r):
        if kind == 'H':
            self.header = r
        elif kind == 'B':
            self.frames, self.lost, self.ended, self.t, self.n = [], 0, None, 0, 0
        elif kind in 'FG':
            self.n += 1
            self.t += r['delta']
            self.frames.append((self.n, self.t, r['delta'], r['frame']))
        elif kind == 'D':
            self.lost += r['count']
        elif kind == 'E':
            self.ended = r

    @property
    def tsc_hz(self):
        return self.header['tsc_hz'] if self.header else None
