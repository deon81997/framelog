#!/usr/bin/env python3
"""flstats.py - frame-time stats and graphs from fllog.py CSV files.

  flstats.py run.csv [more.csv ...] [--png graph.png] [--skip S]

One row per file: frames, duration, average fps, min/max frame time, 1% and 0.1% lows.
Lows = fps at the 99th / 99.9th percentile frame time (the slowest 1% / 0.1% of frames).
--png draws frame time over time (y-axis capped, see --ymax) for every file (multi-machine comparison) plus a sorted frame-time curve.
--skip drops the first S seconds (loading, menus)."""
import argparse
import sys


def load(path):
    meta, rows = {}, []
    for line in open(path):
        line = line.strip()
        if line.startswith('#'):
            k, _, v = line[1:].strip().partition('=')
            meta[k] = v
        elif line and not line.startswith('frame'):
            n, t, ft = line.split(',')
            rows.append((int(n), float(t), float(ft)))
    return meta, rows


def pct(sorted_vals, p):
    """nearest-rank percentile of an ascending list"""
    if not sorted_vals:
        return float('nan')
    k = max(0, min(len(sorted_vals) - 1, int(round(p / 100.0 * len(sorted_vals) + 0.5)) - 1))
    return sorted_vals[k]


def stats(rows):
    ft = sorted(r[2] for r in rows)
    if not ft:
        return None
    dur = sum(ft)
    return {
        'frames': len(ft), 'seconds': dur / 1000.0, 'avg_fps': len(ft) * 1000.0 / dur,
        'avg_ms': dur / len(ft), 'min_ms': ft[0], 'max_ms': ft[-1],
        'low1_fps': 1000.0 / pct(ft, 99), 'low01_fps': 1000.0 / pct(ft, 99.9),
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('csv', nargs='+')
    ap.add_argument('--png')
    ap.add_argument('--skip', type=float, default=0)
    ap.add_argument('--ymax', type=float, default=0, help='frame-time axis limit in ms (default: 4x the 99th percentile, spikes above are clipped)')
    a = ap.parse_args()
    runs = []
    print(f"{'run':24} {'frames':>7} {'sec':>7} {'avg fps':>8} {'avg ms':>7} {'min ms':>7} {'max ms':>8} {'1% low':>7} {'0.1% low':>8} {'lost':>5}")
    for p in a.csv:
        meta, rows = load(p)
        rows = [r for r in rows if r[1] >= a.skip * 1000.0]
        s = stats(rows)
        name = meta.get('label') or p
        runs.append((name, rows))
        if not s:
            print(f"{name[:24]:24} no frames")
            continue
        print(f"{name[:24]:24} {s['frames']:7d} {s['seconds']:7.1f} {s['avg_fps']:8.2f} {s['avg_ms']:7.2f} {s['min_ms']:7.2f} "
              f"{s['max_ms']:8.2f} {s['low1_fps']:7.2f} {s['low01_fps']:8.2f} {meta.get('lost', '?'):>5}")
    if a.png:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(11, 7))
        for name, rows in runs:
            ax1.plot([r[1] / 1000.0 for r in rows], [r[2] for r in rows], lw=0.8, label=name, drawstyle='steps-pre')
            ft = sorted((r[2] for r in rows), reverse=True)
            ax2.plot([100.0 * i / max(1, len(ft) - 1) for i in range(len(ft))], ft, lw=1, label=name)
        ym = a.ymax or 4 * max((pct(sorted(r[2] for r in rows), 99) for _, rows in runs if rows), default=0) or None
        if ym:
            ax1.set_ylim(0, ym); ax2.set_ylim(0, ym)
        ax1.set_xlabel('time (s)'); ax1.set_ylabel('frame time (ms)'); ax1.set_title('Frame time')
        ax2.set_xlabel('% of frames (slowest first)'); ax2.set_ylabel('frame time (ms)'); ax2.set_xscale('symlog', linthresh=1); ax2.set_xlim(0, 100)
        for ax in (ax1, ax2):
            ax.grid(alpha=0.3)
            ax.legend(loc='upper right', fontsize=8)
        fig.tight_layout()
        fig.savefig(a.png, dpi=110)
        print(f"graph -> {a.png}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
