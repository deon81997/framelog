# serial-bench

Host-side tools for [FRAMELOG](https://github.com/deon81997/framelog): frame-time logging for DOS and
Windows 98 games over serial to a second PC. Protocol: framelog/docs/PROTOCOL.md.

Needs Python 3 + `pip install pyserial matplotlib` (flcap.py: + `opencv-python numpy`).

| Tool | What |
|---|---|
| `fllog.py PORT -o run.csv [--label NAME] [--idle S] [--seconds N]` | logger: sends S (start), writes frames to CSV, X (stop) on Ctrl+C. PORT = COM3, /dev/ttyUSB0, or a pyserial URL (socket://127.0.0.1:4555 for QEMU) |
| `fllog.py ... --gpu G --driver D --res WxH --depth BITS --cpu C --game NAME --notes TEXT [--meta file.ini]` | run metadata, stored as `# key=value` comment lines in the CSV; the INI holds `key=value` lines (optional `[meta]` section, extra keys kept), options win over it |
| `fllog.py [PORT] --suite suite.ini [-o DIR]` | suite: several runs back to back (a batch of timedemos), one CSV per run named `game-gpu-res.csv`; a run ends at an E / new B marker or a gap (`gap` s without frames); fragments under `min_frames` are dropped; runs map to the INI's sections in order (format: `fllog.py -h`, example `suites/example.ini`); `--report DIR [--report-src results/]` builds the HTML report when the suite ends |
| `flstats.py a.csv [b.csv ...] [--png g.png] [--skip S] [--label-by gpu,res] [--group-by gpu] [--where key=value]` | stats per run (avg fps, min/max frame time, 1% / 0.1% lows = fps at the 99th / 99.9th percentile frame time) + frame-time graph; several files = machine comparison; `--group-by` adds a table pooling all runs per group |
| `flreport.py FOLDER [...] [-o report/] [--skip S] [--title T] [--where k=v] [--default k=v]` | HTML report from a folder of CSVs (searched recursively): `gpu-<name>.html` per GPU (avg fps, 1% / 0.1% lows, frame-time graph and percentile curve per game, with hover), `compare.html` (all GPUs side by side per game), `index.html`. Grouping by metadata: GPU = `gpu`, game = `game` + `res` + `depth`; `--default gpu="S3 Trio64"` fills metadata older CSVs lack. Self-contained pages, light/dark |
| `flcap.py capture.avi -o run.csv [--fps 70.086] [--crop X,Y,W,H] [--serial run.csv] [--tears t.csv] [--multi-tear 3]` | capture analyzer: frame times from a VGA capture (Datapath etc.) of what reached the screen, row by row - tear lines, repeats, runts, adaptive noise threshold; same CSV format (source=capture) for flstats/flreport; `--serial` aligns it with the fllog CSV of the same run. For copy-to-screen games no trap sees (Heretic, Duke ScreenMode 2). Needs `pip install opencv-python numpy` |
| `flproto.py` | protocol encoder/decoder (resyncs on noise), incl. the `M` metadata record (framelog docs/PROTOCOL.md; the DOS TSR sends gpu/driver/res/depth/cpu/mode since FRAMELOG test4): game-PC metadata fills fields you left empty; a new block mid-run (the game set a mode) = a `# change@N=res=... mode=...` CSV line before frame N |

Game coverage (what FRAMELOG can time, how, and the suite lines to repeat it): [docs/GAMES.md](docs/GAMES.md).

Tests: `python3 -m unittest discover -s tests`. Preview data: `python3 tests/synth.py /tmp/syn && python3 flreport.py /tmp/syn -o /tmp/report`
(3 synthetic GPU suites + look-alikes of the 86Box runs in framelog HANDOFF).

Typical run: game PC `FRAMELOG /COM:1` in AUTOEXEC (after HDPMI32I / SC55); host
`python3 fllog.py COM3 -o duke-d810.csv --label D810`; start the game; Ctrl+C when done;
`python3 flstats.py duke-d810.csv duke-p5pe.csv --png duke.png`.

Roadmap: framelog HANDOFF.md (the project's only handoff).
