#!/usr/bin/env python3
"""fllog.py - FRAMELOG host logger: COM port (or any pyserial URL, e.g. socket://127.0.0.1:4555 for QEMU) -> CSV.

  fllog.py PORT -o run.csv [--baud 115200] [--seconds N] [--idle S] [--label NAME]
            [--gpu G] [--driver D] [--res WxH] [--depth BITS] [--cpu C] [--game NAME] [--notes TEXT] [--meta FILE.INI]
  fllog.py [PORT] --suite suite.ini [-o DIR] [--report REPORT_DIR [--report-src FOLDER]] [same metadata options]

Sends 'S' (start) until the game PC answers with a header, logs frames, and on Ctrl+C / --seconds / --idle
(no frame for S seconds after the first one) sends 'X' (stop). The DOS TSR acts on S/X at the game's next page
flip, so start this before the game or while it runs.
CSV: comment lines (# key=value: label, run metadata gpu/driver/res/depth/cpu/game/notes, source, tsc_hz, ...),
frame,t_ms,frametime_ms rows (written as they come), closing comments (frames, lost, junk, stop=marker|host|gap|
restart; 'host' is normal for DOS: the TSR sees the stop byte at the game's next flip).
Metadata the game PC sends (M records, docs/PROTOCOL-M.md) fills fields left empty here; where it differs from
what you gave, yours stays and the game PC's is written as pc_<key>.

Suites (--suite): several runs back to back (a batch of timedemos), one CSV per run named game-gpu-res.csv
(-2, -3 ... when taken). A run ends at an E marker, a new B marker, or a gap: no frame for `gap` seconds (a frame
whose own time is longer than the gap, or that long without data on the wire); fragments under `min_frames` frames
(menus, loading screens) are dropped. Runs map to the INI's run sections in order; the suite stops after the last.

  [suite]                ; controls + metadata for every run
  name = v3-p2-450
  port = COM3            ; optional, PORT on the command line wins
  out = results          ; output folder (-o wins; default: the INI's folder)
  gap = 5                ; seconds (0 = split only at B/E markers)
  min_frames = 30
  idle = 0               ; stop when no frame came for this long (0 = run until the last section or Ctrl+C)
  gpu = Voodoo3 3000
  cpu = Pentium II 450
  [duke]                 ; one section per run, in play order; game defaults to the section name
  game = Duke3D 1.3D demo1
  res = 320x200
  depth = 8
Metadata order: [suite] / [meta] < command-line options < the run's section.
--report REPORT_DIR runs flreport.py when the suite ends, on the suite's output folder or on --report-src (point it at
the folder that holds every GPU's results to get the side-by-side page too)."""
import argparse
import configparser
import os
import sys
import time

import flmeta
from flproto import Decoder, MetaText, Timeline, SOURCES

SUITE_KEYS = {'name', 'port', 'out', 'baud', 'gap', 'min_frames', 'idle', 'seconds'}


class CsvOut:
    """streams frames to the CSV as they arrive (a crash or a pulled cable keeps what was logged)"""

    def __init__(self, path, label, meta=None, extra=None):
        self.path = path
        self.f = open(path, 'w')
        self.f.write(f"# label={flmeta.clean(label)}\n")
        self.meta = dict(meta or {})
        self.f.writelines(flmeta.lines(self.meta))
        for k, v in (extra or {}).items():
            self.f.write(f"# {k}={v}\n")
        self.hz = None
        self.h = None
        self.pc = {}             # metadata from the game PC (M records), written at begin()
        self.begun = False
        self.rows = 0

    def header(self, h):
        self.hz = h['tsc_hz'] or 1
        self.h = h

    def begin(self):
        """header comments + column row, once: at the first frame (M records come between H and B)"""
        if self.begun or not self.h:
            return
        self.begun = True
        merged = flmeta.with_pc(self.meta, self.pc)
        self.f.writelines(flmeta.lines({k: v for k, v in merged.items() if self.meta.get(k) != v}))
        h = self.h
        self.f.write(f"# source={SOURCES.get(h['source'], h['source'])}\n# tsc_hz={self.hz}\n# modes={h['modes']}\n")
        self.f.write("frame,t_ms,frametime_ms\n")

    def meta_change(self, m):
        """an M block from the game PC: before the first frame it fills the header; later (the game set a new mode)
        one '# change@N=key=value ...' line with what changed ('key=' = gone), N = the next frame"""
        if not self.begun:
            self.pc = m
            return
        ch = {k: v for k, v in m.items() if self.pc.get(k) != v}
        ch.update({k: '' for k in self.pc if k not in m})     # gone (text mode: no res/depth) -> 'res='
        self.pc = m
        if ch:
            self.f.write(f"# change@{self.rows + 1}=" + ' '.join(f"{k}={flmeta.clean(v)}" for k, v in ch.items()) + "\n")

    def frame(self, n, t, d):
        if self.hz:
            self.begin()
            self.f.write(f"{n},{t * 1000.0 / self.hz:.4f},{d * 1000.0 / self.hz:.4f}\n")
            self.rows += 1
            if self.rows % 64 == 0:
                self.f.flush()

    def finish(self, frames, lost, junk, stop, ended=None):
        self.begin()
        self.f.write(f"# frames={frames}\n# lost={lost}\n# junk={junk}\n# stop={stop}\n")
        if ended:
            self.f.write(f"# end_frames={ended['frames']}\n# end_lost={ended['lost']}\n")
        self.f.close()

    def close(self, tl, junk):
        # 'host' is normal for DOS: the TSR reads the stop byte at the game's next page flip
        self.finish(len(tl.frames), tl.lost, junk, 'marker' if tl.ended else 'host', tl.ended)


class Splitter:
    """Cuts the decoded record stream into runs. sink.open(header) -> run object with .frame(n, t, d);
    sink.close(run, frames, lost, stop, ended) keeps it, sink.drop(run, frames) throws a fragment away.
    Ticks are the game PC's TSC; t restarts at 0 at each run's origin (B marker or the gap frame)."""

    def __init__(self, sink, gap=0.0, min_frames=0):
        self.sink, self.gap, self.min_frames = sink, gap, min_frames
        self.header = None
        self.mt = MetaText()
        self.pc = {}
        self.run = None
        self.n = self.t = self.lost = 0
        self.from_b = False          # this run started at a B marker (E totals then belong to it)
        self.after_b = False
        self.last_data = None

    @property
    def hz(self):
        return (self.header['tsc_hz'] or 1) if self.header else None

    def feed(self, kind, r, now=0.0):
        if kind == 'H':
            self.header = r
            self.pc = {}
        elif kind == 'M':
            m = self.mt.add(r)
            if m is not None:
                self.pc = m
                if self.run is not None and hasattr(self.run, 'meta_change'):
                    self.run.meta_change(m)      # mid-run block: the game set a new mode
        elif kind == 'B':
            self.close('restart')
            self.after_b = True
            self.lost = 0
        elif kind in 'FG':
            self.last_data = now
            if self.header is None:
                return
            d = r['delta']
            if self.gap and d > self.gap * self.hz:
                self.close('gap')            # this frame's time is the gap: it is the next run's origin, not a row
                self.after_b = False
                return
            if self.run is None:
                self.run = self.sink.open(self.header, self.pc)
                self.n = self.t = 0
                self.from_b, self.after_b = self.after_b, False
            self.n += 1
            self.t += d
            self.run.frame(self.n, self.t, d)
        elif kind == 'D':
            self.lost += r['count']
        elif kind == 'E':
            self.close('marker', r)
            self.after_b = False

    def tick(self, now):
        """wall clock: no frame for `gap` seconds closes the open run"""
        if self.run is not None and self.gap and self.last_data is not None and now - self.last_data > self.gap:
            self.close('gap')

    def close(self, stop, ended=None):
        if self.run is None:
            return
        run, self.run = self.run, None
        if self.n < self.min_frames:
            self.sink.drop(run, self.n)
        else:
            self.sink.close(run, self.n, self.lost, stop, ended if self.from_b else None)
        self.lost = 0


def read_suite(path):
    """suite INI -> (controls, suite metadata, [(section, run metadata)])"""
    cp = configparser.ConfigParser(interpolation=None, inline_comment_prefixes=(';',), strict=False)
    cp.optionxform = str
    with open(path, encoding='utf-8') as f:
        cp.read_file(f)
    ctl, meta, runs = {}, {}, []
    for sec in cp.sections():
        items = {flmeta.norm_key(k): flmeta.clean(v) for k, v in cp.items(sec)}
        if sec.lower() == 'suite':
            ctl = {k: v for k, v in items.items() if k in SUITE_KEYS}
            meta.update({k: v for k, v in items.items() if k not in SUITE_KEYS})
        elif sec.lower() == 'meta':
            meta.update(items)
        else:
            runs.append((sec, flmeta.merge({'game': sec}, items)))
    return ctl, meta, runs


def run_filename(meta, n):
    parts = [flmeta.slug(meta[k]) for k in ('game', 'gpu', 'res') if meta.get(k)]
    return '-'.join(parts) if parts else f'run{n}'


def unique_path(folder, stem, taken):
    p = os.path.join(folder, stem + '.csv')
    i = 2
    while p in taken or os.path.exists(p):
        p = os.path.join(folder, f'{stem}-{i}.csv')
        i += 1
    taken.add(p)
    return p


class Suite:
    """Splitter sink: one CsvOut per kept run, named after the next run section."""

    def __init__(self, folder, label, base_meta, sections, name='', log=None):
        self.folder, self.label, self.base, self.sections, self.name = folder, label, base_meta, sections, name
        self.log = log or (lambda s: None)
        self.done = []               # paths of kept runs
        self.dropped = 0
        self.junk = 0                # decoder junk total (set by the caller)
        self._junk0 = 0
        self.taken = set()
        os.makedirs(folder, exist_ok=True)

    @property
    def finished(self):
        return bool(self.sections) and len(self.done) >= len(self.sections)

    def open(self, header, pc=None):
        i = len(self.done)
        sec, rmeta = self.sections[i] if i < len(self.sections) else (f'run{i + 1}', {'game': f'run{i + 1}'})
        meta = flmeta.merge(self.base, rmeta)
        path = unique_path(self.folder, run_filename(flmeta.with_pc(meta, pc), i + 1), self.taken)
        extra = {'run': i + 1}
        if self.name:
            extra = {'suite': self.name, 'run': i + 1}
        out = CsvOut(path + '.part', self.label, meta, extra)
        out.final, out.section = path, sec
        out.pc = pc or {}
        out.header(header)
        self._junk0 = self.junk
        self.log(f"run {i + 1}/{len(self.sections) or '?'} [{sec}] -> {os.path.basename(path)}")
        return out

    def close(self, run, frames, lost, stop, ended):
        run.finish(frames, lost, self.junk - self._junk0, stop, ended)
        os.replace(run.path, run.final)
        self.done.append(run.final)
        self.log(f"  {frames} frames, {lost} lost, stop={stop}")

    def drop(self, run, frames):
        run.f.close()
        os.remove(run.path)
        self.taken.discard(run.final)
        self.dropped += 1
        self.log(f"  dropped a {frames}-frame fragment (min_frames)")


def open_port(url, baud):
    import serial
    return serial.serial_for_url(url, baudrate=baud, timeout=0.05)


def log_suite(a, cli_meta):
    import serial
    ctl, smeta, sections = read_suite(a.suite)
    port = a.port or ctl.get('port')
    if not port:
        sys.exit("fllog: no PORT (command line or [suite] port=)")
    folder = a.out or ctl.get('out') or '.'
    if not os.path.isabs(folder) and not a.out:
        folder = os.path.join(os.path.dirname(os.path.abspath(a.suite)), folder)
    gap = float(ctl.get('gap', 5))
    min_frames = int(ctl.get('min_frames', 30))
    idle = a.idle or float(ctl.get('idle', 0))
    seconds = a.seconds or float(ctl.get('seconds', 0))
    baud = int(ctl.get('baud', a.baud))
    say = (lambda s: None) if a.quiet else (lambda s: print(s, file=sys.stderr))
    base = flmeta.merge(smeta, cli_meta)
    suite = Suite(folder, a.label or ctl.get('name', ''), base, sections, ctl.get('name', ''), say)
    sp = Splitter(suite, gap, min_frames)
    ser = open_port(port, baud)
    dec = Decoder()
    t0 = time.time()
    last_s, sending, orphan, last_frame = 0.0, True, 0, 0.0

    def handle(records, now):
        nonlocal sending, orphan, last_frame
        for kind, r in records:
            suite.junk = dec.junk
            if kind == 'H':
                sending = False
                say(f"header: {SOURCES.get(r['source'], r['source'])}, TSC {r['tsc_hz'] / 1e6:.2f} MHz")
            elif kind == 'E':
                sending = True       # wait for the next game's log
            elif kind in 'FG':
                last_frame = now
                if sp.header is None:
                    orphan += 1
                    if orphan == 1:
                        ser.write(b'XS')
            sp.feed(kind, r, now)
        suite.junk = dec.junk

    try:
        while not suite.finished:
            now = time.time()
            if sending and now - last_s > 0.25:
                ser.write(b'S')
                last_s = now
            handle(dec.feed(ser.read(4096)), now)
            sp.tick(time.time())
            if seconds and now - t0 > seconds:
                break
            if idle and last_frame and now - last_frame > idle:
                break
    except KeyboardInterrupt:
        pass
    except serial.SerialException as e:
        say(f"port closed: {e}")
    try:
        ser.write(b'X')
        end = time.time() + 0.5
        while time.time() < end:
            handle(dec.feed(ser.read(4096)), time.time())
        ser.close()
    except serial.SerialException:
        pass
    sp.close('host')
    say(f"suite: {len(suite.done)} runs kept, {suite.dropped} fragments dropped, {dec.junk} junk bytes -> {folder}")
    for p in suite.done:
        print(p)
    if a.report and suite.done:
        import flreport
        files = flreport.build([a.report_src or folder], a.report, title=f"FRAMELOG {ctl.get('name', '')}".strip(),
                               log=say)
        say(f"report: {os.path.join(a.report, 'index.html')} ({len(files)} pages)")
    return 0 if suite.done else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('port', nargs='?')
    ap.add_argument('-o', '--out', help='CSV file (suite: output folder)')
    ap.add_argument('--suite', metavar='SUITE.INI', help='log several runs back to back, one CSV per run')
    ap.add_argument('--report', metavar='DIR', help='suite: write the HTML report here when it ends')
    ap.add_argument('--report-src', metavar='FOLDER', help='suite: CSV folder for --report (default: the suite output)')
    ap.add_argument('--baud', type=int, default=115200)
    ap.add_argument('--seconds', type=float, default=0, help='stop after this long (0 = until Ctrl+C)')
    ap.add_argument('--idle', type=float, default=0, help='stop when no frame came for this long (after the first)')
    ap.add_argument('--label', default='')
    ap.add_argument('-q', '--quiet', action='store_true')
    flmeta.add_args(ap)
    a = ap.parse_args()
    meta = flmeta.from_args(a)
    if a.suite:
        return log_suite(a, meta)
    if not a.port or not a.out:
        ap.error('PORT and -o are required without --suite')
    import serial

    ser = open_port(a.port, a.baud)
    dec, tl, mt = Decoder(), Timeline(), MetaText()
    out = CsvOut(a.out, a.label, meta)
    t0 = time.time()
    orphan = 0           # frames before any header: the game PC was still logging from an earlier session
    last_s = last_frame = 0.0
    started = False
    try:
        while True:
            now = time.time()
            if not started and now - last_s > 0.25:
                ser.write(b'S')
                last_s = now
            for kind, r in dec.feed(ser.read(4096)):
                tl.add(kind, r)
                if kind in 'FG' and not started:
                    orphan += 1
                    if orphan == 1:
                        ser.write(b'XS')    # stop the old log, start ours
                    continue
                if kind == 'M' and started:
                    m = mt.add(r)
                    if m is not None:
                        out.meta_change(m)
                if kind == 'H':
                    started = True
                    out.header(r)
                    if not a.quiet:
                        print(f"header: {SOURCES.get(r['source'], r['source'])}, TSC {r['tsc_hz'] / 1e6:.2f} MHz", file=sys.stderr)
                if kind in 'FG':
                    last_frame = now
                    out.frame(*tl.frames[-1][:3])
            if a.seconds and now - t0 > a.seconds:
                break
            if a.idle and last_frame and now - last_frame > a.idle:
                break
    except KeyboardInterrupt:
        pass
    except serial.SerialException as e:     # port gone (USB adapter pulled, QEMU quit)
        print(f"port closed: {e}", file=sys.stderr)
    try:
        ser.write(b'X')
        end = time.time() + 0.5
        while time.time() < end and tl.ended is None:
            for kind, r in dec.feed(ser.read(4096)):
                tl.add(kind, r)
                if kind in 'FG' and started:
                    out.frame(*tl.frames[-1][:3])
        ser.close()
    except serial.SerialException:
        pass
    out.close(tl, dec.junk)
    if not a.quiet:
        print(f"{len(tl.frames)} frames, {tl.lost} lost, {dec.junk} junk bytes -> {a.out}", file=sys.stderr)
    return 0 if tl.frames else 1


if __name__ == '__main__':
    sys.exit(main())
