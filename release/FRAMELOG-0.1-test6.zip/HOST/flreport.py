#!/usr/bin/env python3
"""flreport.py - HTML benchmark report from a folder of fllog.py CSVs.

  flreport.py FOLDER [FOLDER ...] [-o report/] [--skip S] [--title TEXT] [--where key=value ...]

Writes one page per GPU (gpu-<name>.html: per game avg fps, 1% / 0.1% lows, frame-time graph and percentile
curve) plus compare.html (all GPUs side by side per game) and index.html. Self-contained pages: no scripts or
fonts from the net. Runs are grouped by the CSV metadata (fllog.py --gpu/--game/--res/--depth or a suite):
GPU = gpu (else label, else "unknown GPU"), test = game + res + depth (game else label else file name).
Several runs of one test on one GPU are listed one by one and pooled for the summary.
CSV folders are searched recursively; files that are not fllog CSVs are skipped with a warning.
--default key=value fills metadata older CSVs lack (e.g. --default gpu="86Box S3" for pre-metadata logs)."""
import argparse
import html
import json
import math
import os
import sys

import flmeta
import flstats

# categorical slots in fixed order (validated: dataviz validate_palette.js, light + dark)
LIGHT = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#6250d6', '#e34948']
DARK = ['#3987e5', '#d95926', '#199e70', '#c98500', '#d55181', '#0ca30c', '#9085e9', '#e66767']
MAX_SERIES = len(LIGHT)
MAX_POINTS = 1200        # frame-time graph: more frames -> max per bucket (keeps the spikes)

CSS = """
.viz-root{color-scheme:light;--surface-1:#fcfcfb;--surface-2:#f4f3f0;--grid:#e6e5e1;--text-primary:#0b0b0b;
--text-secondary:#52514e;--text-muted:#77766f;%LIGHT%}
@media (prefers-color-scheme:dark){:root:where(:not([data-theme="light"])) .viz-root{color-scheme:dark;
--surface-1:#1a1a19;--surface-2:#232321;--grid:#383835;--text-primary:#f0efec;--text-secondary:#c3c2b7;
--text-muted:#9a998f;%DARK%}}
:root[data-theme="dark"] .viz-root{color-scheme:dark;--surface-1:#1a1a19;--surface-2:#232321;--grid:#383835;
--text-primary:#f0efec;--text-secondary:#c3c2b7;--text-muted:#9a998f;%DARK%}
body{margin:0}
.viz-root{background:var(--surface-1);color:var(--text-primary);font:14px/1.45 system-ui,-apple-system,"Segoe UI",
Roboto,sans-serif;padding:24px 32px 48px;min-height:100vh;box-sizing:border-box}
h1{font-size:24px;margin:0 0 4px}h2{font-size:18px;margin:36px 0 4px}h3{font-size:14px;margin:16px 0 6px;
color:var(--text-secondary);font-weight:600}
a{color:inherit}.sub{color:var(--text-secondary);margin:0 0 16px}.nav{margin:0 0 20px;color:var(--text-secondary)}
table{border-collapse:collapse;margin:8px 0 12px;font-variant-numeric:tabular-nums}
th,td{padding:4px 12px 4px 0;text-align:right;border-bottom:1px solid var(--grid);white-space:nowrap}
th{color:var(--text-secondary);font-weight:600}th:first-child,td:first-child{text-align:left}
td.l{text-align:left;white-space:normal}.muted{color:var(--text-muted)}
.charts{display:flex;flex-wrap:wrap;gap:16px 32px}.chart{position:relative;width:560px;max-width:100%}
svg{max-width:100%;height:auto}
.chart .t{font-weight:600;font-size:13px;margin:0 0 2px}.chart .n{font-size:12px;color:var(--text-muted);margin:2px 0 0}
.legend{display:flex;flex-wrap:wrap;gap:4px 16px;font-size:12px;color:var(--text-secondary);margin:0 0 4px}
.legend span{display:inline-flex;align-items:center;gap:6px}.legend i{display:inline-block;width:14px;height:2px;
border-radius:1px}
svg text{fill:var(--text-secondary);font-size:11px}svg .grid{stroke:var(--grid);stroke-width:1}
svg .ser{fill:none;stroke-width:2;stroke-linejoin:round;stroke-linecap:round}
svg .xh{stroke:var(--text-muted);stroke-width:1;visibility:hidden}
svg .bar:hover{opacity:.8}
.tip{position:absolute;pointer-events:none;background:var(--surface-2);color:var(--text-primary);border:1px solid
var(--grid);border-radius:6px;padding:6px 8px;font-size:12px;white-space:nowrap;visibility:hidden;
box-shadow:0 2px 8px rgba(0,0,0,.15);z-index:2}.tip b{font-weight:600}.tip i{display:inline-block;width:8px;
height:8px;border-radius:4px;margin-right:6px}
"""
CSS = (CSS.replace('%LIGHT%', ''.join(f'--series-{i + 1}:{c};' for i, c in enumerate(LIGHT)))
       .replace('%DARK%', ''.join(f'--series-{i + 1}:{c};' for i, c in enumerate(DARK))))

# crosshair + tooltip for line charts (data in the svg's data-series), tooltips for bars (data-tip)
JS = r"""
document.querySelectorAll('svg[data-series]').forEach(function(svg){
 var d=JSON.parse(svg.getAttribute('data-series')),box=svg.parentNode,tip=box.querySelector('.tip'),
 xh=svg.querySelector('.xh');
 function hide(){tip.style.visibility='hidden';xh.style.visibility='hidden';}
 svg.addEventListener('pointerleave',hide);
 svg.addEventListener('pointermove',function(e){
  var r=svg.getBoundingClientRect(),vb=svg.viewBox.baseVal,px=(e.clientX-r.left)*vb.width/r.width;
  if(px<d.x0||px>d.x1){hide();return;}
  var rows=[],xv=null;
  d.s.forEach(function(s){var p=s.p,lo=0,hi=p.length-1;if(!p.length)return;
   while(hi-lo>1){var m=(lo+hi)>>1;if(p[m][0]<px)lo=m;else hi=m;}
   var q=Math.abs(p[lo][0]-px)<Math.abs(p[hi][0]-px)?p[lo]:p[hi];if(xv===null)xv=q[2];
   rows.push('<div><i style="background:var(--series-'+s.c+')"></i>'+s.n+' <b>'+q[3]+'</b></div>');});
  xh.setAttribute('x1',px);xh.setAttribute('x2',px);xh.style.visibility='visible';
  tip.innerHTML='<div class="muted">'+d.xl+' '+xv+'</div>'+rows.join('');tip.style.visibility='visible';
  var bx=box.getBoundingClientRect(),tx=e.clientX-bx.left+14;
  if(tx+tip.offsetWidth>bx.width)tx=e.clientX-bx.left-tip.offsetWidth-14;
  tip.style.left=tx+'px';tip.style.top=(e.clientY-bx.top+10)+'px';});
});
document.querySelectorAll('svg .bar').forEach(function(b){
 var box=b.closest('.chart'),tip=box.querySelector('.tip');
 b.addEventListener('pointerleave',function(){tip.style.visibility='hidden';});
 b.addEventListener('pointermove',function(e){var bx=box.getBoundingClientRect();
  tip.innerHTML=b.getAttribute('data-tip');tip.style.visibility='visible';
  tip.style.left=(e.clientX-bx.left+14)+'px';tip.style.top=(e.clientY-bx.top+10)+'px';});
});
"""

esc = html.escape


# ---------- data ----------

class Run:
    def __init__(self, path, meta, rows):
        self.path, self.meta, self.rows = path, meta, rows
        self.stats = flstats.stats(rows)
        stem = os.path.splitext(os.path.basename(path))[0]
        self.gpu = meta.get('gpu') or meta.get('label') or 'unknown GPU'
        self.game = meta.get('game') or meta.get('label') or stem
        parts = [self.game, meta.get('res', '')]
        if meta.get('depth'):
            parts.append(meta['depth'] + '-bit')
        self.test = ' · '.join(p for p in parts if p)
        self.name = os.path.basename(path)


def find_csvs(folders):
    out = []
    for f in folders:
        if os.path.isfile(f):
            out.append(f)
            continue
        for root, dirs, files in os.walk(f):
            dirs.sort()
            out += [os.path.join(root, n) for n in sorted(files) if n.lower().endswith('.csv')]
    return out


def load_runs(paths, skip=0.0, wheres=(), warn=None, defaults=None):
    runs = []
    for p in paths:
        try:
            meta, rows = flstats.load(p)
        except (ValueError, UnicodeDecodeError, OSError) as e:
            if warn:
                warn(f"skipped {p}: not a fllog CSV ({e})")
            continue
        for k, v in (defaults or {}).items():
            meta.setdefault(k, v)
        if not flstats.matches(meta, wheres):
            continue
        rows = [r for r in rows if r[1] >= skip * 1000.0]
        if not rows:
            if warn:
                warn(f"skipped {p}: no frames")
            continue
        runs.append(Run(p, meta, rows))
    return runs


def by_gpu(runs):
    """{gpu: {test: [runs]}} keeping first-seen order"""
    out = {}
    for r in runs:
        out.setdefault(r.gpu, {}).setdefault(r.test, []).append(r)
    return out


def pooled(runs):
    return flstats.stats([row for r in runs for row in r.rows])


# ---------- svg helpers ----------

def nice_step(span, n=5):
    if span <= 0:
        return 1.0
    raw = span / n
    mag = 10 ** math.floor(math.log10(raw))
    for m in (1, 2, 2.5, 5, 10):
        if raw <= m * mag:
            return m * mag
    return 10 * mag


def ticks(vmax, n=5):
    step = nice_step(vmax, n)
    top = step * math.ceil(vmax / step - 1e-9) if vmax > 0 else step
    k = int(round(top / step))
    return [i * step for i in range(k + 1)], top


def num(v):
    if v >= 1000:
        return f"{v:,.0f}"
    return f"{v:g}" if v == int(v) else f"{v:.1f}"


def legend(names):
    if len(names) < 2:
        return ''
    return '<div class="legend">' + ''.join(
        f'<span><i style="background:var(--series-{i % MAX_SERIES + 1})"></i>{esc(n)}</span>'
        for i, n in enumerate(names)) + '</div>'


def frame_points(rows):
    """[(t_s, ft_ms)], max per bucket above MAX_POINTS"""
    if len(rows) <= MAX_POINTS:
        return [(r[1] / 1000.0, r[2]) for r in rows]
    k = math.ceil(len(rows) / (MAX_POINTS / 2))
    out = []
    for i in range(0, len(rows), k):
        b = rows[i:i + k]
        m = max(b, key=lambda r: r[2])
        out.append((m[1] / 1000.0, m[2]))
    return out


def pct_x(p):
    """percentile -> x on a 'nines' axis: 0 % -> 0, 90 -> 1, 99 -> 2, 99.9 -> 3"""
    return -math.log10(max(1e-3, 1 - p / 100.0))


def pct_points(rows, n=240):
    ft = sorted(r[2] for r in rows)
    pts = []
    for i in range(n + 1):
        x = 3.0 * i / n
        p = 100.0 * (1 - 10 ** -x)
        pts.append((x, flstats.pct(ft, p), p))
    return pts


def line_chart(series, xlabel, ylabel, xticks, xfmt, tipy, xmax, ymax_hint=None, w=560, h=220, note='', step=False):
    """series = [(name, slot, [(x, y, xshow)])]; xticks = [(value, label)]"""
    ml, mr, mt, mb = 44, 12, 8, 30
    pw, ph = w - ml - mr, h - mt - mb
    ys = [p[1] for _, _, pts in series for p in pts]
    ymax = ymax_hint or (max(ys) if ys else 1)
    yt, ytop = ticks(ymax)
    clipped = any(y > ytop for y in ys)
    X = lambda x: ml + pw * (x / xmax if xmax else 0)       # noqa: E731
    Y = lambda y: mt + ph * (1 - min(y, ytop) / ytop)       # noqa: E731
    o = [f'<svg viewBox="0 0 {w} {h}" width="{w}" height="{h}" role="img" aria-label="{esc(ylabel)} by {esc(xlabel)}"']
    data = {'x0': ml, 'x1': ml + pw, 'xl': xlabel, 's': []}
    for name, slot, pts in series:
        data['s'].append({'n': esc(name), 'c': slot % MAX_SERIES + 1,
                          'p': [[round(X(p[0]), 1), 0, xfmt(p), tipy(p)] for p in pts]})
    o[0] += f" data-series='{esc(json.dumps(data, separators=(',', ':')), quote=True)}'>"
    for v in yt:
        o.append(f'<line class="grid" x1="{ml}" x2="{ml + pw}" y1="{Y(v):.1f}" y2="{Y(v):.1f}"/>'
                 f'<text x="{ml - 6}" y="{Y(v) + 4:.1f}" text-anchor="end">{num(v)}</text>')
    for v, lab in xticks:
        o.append(f'<text x="{X(v):.1f}" y="{mt + ph + 16}" text-anchor="middle">{esc(lab)}</text>')
    o.append(f'<text x="{ml + pw}" y="{h - 2}" text-anchor="end">{esc(xlabel)}</text>')
    o.append(f'<text transform="translate(10,{mt + ph / 2:.0f}) rotate(-90)" text-anchor="middle">{esc(ylabel)}</text>')
    for name, slot, pts in series:
        if step:    # a frame's time covers the interval that ends at its timestamp (steps-pre)
            xy, prev = [], 0.0
            for p in pts:
                xy += [(prev, p[1]), (p[0], p[1])]
                prev = p[0]
        else:
            xy = [(p[0], p[1]) for p in pts]
        d = ' '.join(f'{X(x):.1f},{Y(y):.1f}' for x, y in xy)
        o.append(f'<polyline class="ser" style="stroke:var(--series-{slot % MAX_SERIES + 1})" points="{d}">'
                 f'<title>{esc(name)}</title></polyline>')
    o.append(f'<line class="xh" x1="0" x2="0" y1="{mt}" y2="{mt + ph}"/></svg>')
    if clipped:
        note = (note + ' ' if note else '') + f'Spikes above {num(ytop)} ms are cut at the top; the tables have the real maximum.'
    return ''.join(o), note


def frametime_chart(title, runs_named):
    """runs_named = [(name, slot, rows)]"""
    series, xmax, p99s = [], 0.0, []
    bucketed = False
    for name, slot, rows in runs_named:
        pts = frame_points(rows)
        bucketed |= len(pts) < len(rows)
        series.append((name, slot, [(t, ft, None) for t, ft in pts]))
        xmax = max(xmax, rows[-1][1] / 1000.0)
        p99s.append(flstats.pct(sorted(r[2] for r in rows), 99))
    step = nice_step(xmax, 6)
    xt = [(i * step, num(i * step)) for i in range(int(xmax / step) + 1)]
    svg, note = line_chart(series, 'time (s)', 'frame time (ms)', xt, lambda p: f'{p[0]:.2f} s',
                           lambda p: f'{p[1]:.2f} ms', xmax or 1, 4 * max(p99s),
                           note='Slowest frame per time slice shown.' if bucketed else '', step=True)
    return chart_box(title, svg, [n for n, _, _ in runs_named], note)


def percentile_chart(title, runs_named):
    series = [(name, slot, pct_points(rows)) for name, slot, rows in runs_named]
    xt = [(0, '0'), (pct_x(50), '50'), (1, '90'), (2, '99'), (3, '99.9')]
    ymax = max(p[1] for _, _, pts in series for p in pts)
    svg, note = line_chart(series, 'percentile', 'frame time (ms)', xt, lambda p: f'{p[2]:.2f} %',
                           lambda p: f'{p[1]:.2f} ms ({1000.0 / p[1]:.1f} fps)' if p[1] else '-', 3, ymax,
                           note='Frame time at each percentile; 99 = the 1% low, 99.9 = the 0.1% low.')
    return chart_box(title, svg, [n for n, _, _ in runs_named], note)


def chart_box(title, svg, names, note=''):
    return (f'<div class="chart"><div class="t">{esc(title)}</div>{legend(names)}{svg}'
            + (f'<div class="n">{esc(note)}</div>' if note else '') + '<div class="tip"></div></div>')


def bar_chart(title, items, unit='fps', w=560):
    """items = [(name, slot, value, tip)] horizontal bars, one baseline, value at the tip"""
    if not items:
        return ''
    lab_w, bar_h, gap, mt = 170, 20, 10, 4
    pw = w - lab_w - 70
    vmax = max(v for _, _, v, _ in items) or 1
    h = mt + len(items) * (bar_h + gap) + 4
    o = [f'<svg viewBox="0 0 {w} {h}" width="{w}" height="{h}" role="img" aria-label="{esc(title)}">']
    for i, (name, slot, v, tip) in enumerate(items):
        y = mt + i * (bar_h + gap)
        bw = max(2.0, pw * v / vmax)
        r = min(4.0, bw / 2)
        x0 = lab_w
        d = (f'M{x0},{y} H{x0 + bw - r:.1f} Q{x0 + bw:.1f},{y} {x0 + bw:.1f},{y + r} V{y + bar_h - r} '
             f'Q{x0 + bw:.1f},{y + bar_h} {x0 + bw - r:.1f},{y + bar_h} H{x0} Z')
        short = name if len(name) <= 26 else name[:25] + '…'
        o.append(f'<text x="{lab_w - 8}" y="{y + bar_h / 2 + 4}" text-anchor="end">{esc(short)}<title>{esc(name)}</title></text>'
                 f'<path class="bar" d="{d}" style="fill:var(--series-{slot % MAX_SERIES + 1})" '
                 f'data-tip="{esc(tip, quote=True)}"/>'
                 f'<text x="{x0 + bw + 6:.1f}" y="{y + bar_h / 2 + 4}" style="fill:var(--text-primary)">{v:.1f}</text>')
    o.append(f'<line class="grid" x1="{lab_w}" x2="{lab_w}" y1="0" y2="{h}"/></svg>')
    return chart_box(title, ''.join(o), [], f'Average {unit}; hover a bar for the lows.')


# ---------- pages ----------

def page(title, sub, body, nav):
    return (f'<!DOCTYPE html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" '
            f'content="width=device-width,initial-scale=1"><title>{esc(title)}</title><style>{CSS}</style></head>'
            f'<body><div class="viz-root"><div class="nav">{nav}</div><h1>{esc(title)}</h1><p class="sub">{sub}</p>'
            f'{body}</div><script>{JS}</script></body></html>\n')


_FILES = {}     # gpu -> page name, unique per report (set by build)


def gpu_file(gpu):
    if gpu not in _FILES:
        stem, i = 'gpu-' + flmeta.slug(gpu, 'unknown'), 2
        name = stem + '.html'
        while name in _FILES.values():
            name, i = f'{stem}-{i}.html', i + 1
        _FILES[gpu] = name
    return _FILES[gpu]


STAT_HEAD = ('<tr><th>{}</th><th>avg fps</th><th>1% low</th><th>0.1% low</th><th>frames</th><th>seconds</th>'
             '<th>min ms</th><th>max ms</th>{}</tr>')


def stat_cells(s):
    return (f'<td>{s["avg_fps"]:.1f}</td><td>{s["low1_fps"]:.1f}</td><td>{s["low01_fps"]:.1f}</td>'
            f'<td>{s["frames"]}</td><td>{s["seconds"]:.1f}</td><td>{s["min_ms"]:.2f}</td><td>{s["max_ms"]:.2f}</td>')


def distinct(runs, key):
    vals = []
    for r in runs:
        v = r.meta.get(key)
        if v and v not in vals:
            vals.append(v)
    return ', '.join(vals)


def gpu_page(gpu, tests, title, nav):
    allruns = [r for rs in tests.values() for r in rs]
    info = []
    for k, lab in (('driver', 'Driver'), ('cpu', 'CPU'), ('source', 'Logged from')):
        v = distinct(allruns, k)
        if v:
            info.append(f'{lab}: {esc(v)}')
    body = ['<h2>Summary</h2><table>', STAT_HEAD.format('game', '<th>runs</th>')]
    for test, runs in tests.items():
        body.append(f'<tr><td class="l"><a href="#{flmeta.slug(test)}">{esc(test)}</a></td>'
                    f'{stat_cells(pooled(runs))}<td>{len(runs)}</td></tr>')
    body.append('</table>')
    for test, runs in tests.items():
        body.append(f'<h2 id="{flmeta.slug(test)}">{esc(test)}</h2>')
        notes = distinct(runs, 'notes')
        if notes:
            body.append(f'<p class="sub">{esc(notes)}</p>')
        body.append('<table>' + STAT_HEAD.format('run', '<th>lost</th><th>driver</th>'))
        for r in runs:
            body.append(f'<tr><td class="l">{esc(r.name)}</td>{stat_cells(r.stats)}'
                        f'<td>{esc(r.meta.get("lost", "?"))}</td><td class="l">{esc(r.meta.get("driver", ""))}</td></tr>')
        if len(runs) > 1:
            body.append(f'<tr><td class="l"><b>all runs</b></td>{stat_cells(pooled(runs))}<td></td><td></td></tr>')
        body.append('</table>')
        shown = runs[:MAX_SERIES]
        named = [(r.name if len(runs) > 1 else test, i, r.rows) for i, r in enumerate(shown)]
        body.append('<div class="charts">' + frametime_chart('Frame time', named)
                    + percentile_chart('Frame-time percentiles', named) + '</div>')
        if len(runs) > MAX_SERIES:
            body.append(f'<p class="muted">Charts show the first {MAX_SERIES} runs; the table has all {len(runs)}.</p>')
    sub = esc(gpu) + (' — ' + ' · '.join(info) if info else '')
    return page(f'{title}: {gpu}', sub, ''.join(body), nav)


def compare_page(gpus, title, nav):
    names = list(gpus)
    tests = []
    for g in names:
        for t in gpus[g]:
            if t not in tests:
                tests.append(t)
    head = ''.join(f'<th colspan="3"><a href="{gpu_file(g)}">{esc(g)}</a></th>' for g in names)
    sub_head = '<th>avg</th><th>1%</th><th>0.1%</th>' * len(names)
    body = ['<h2>All games</h2><p class="sub">fps: average, 1% low, 0.1% low (all runs of a game pooled)</p>',
            f'<table><tr><th></th>{head}</tr><tr><th>game</th>{sub_head}</tr>']
    for t in tests:
        cells = []
        for g in names:
            runs = gpus[g].get(t)
            if runs:
                s = pooled(runs)
                cells.append(f'<td>{s["avg_fps"]:.1f}</td><td>{s["low1_fps"]:.1f}</td><td>{s["low01_fps"]:.1f}</td>')
            else:
                cells.append('<td class="muted">–</td>' * 3)
        body.append(f'<tr><td class="l"><a href="#{flmeta.slug(t)}">{esc(t)}</a></td>{"".join(cells)}</tr>')
    body.append('</table>')
    if len(names) > MAX_SERIES:
        body.append(f'<p class="muted">Charts show the first {MAX_SERIES} GPUs; the table has all {len(names)}.</p>')
    for t in tests:
        have = [(i, g) for i, g in enumerate(names) if t in gpus[g]][:MAX_SERIES]
        body.append(f'<h2 id="{flmeta.slug(t)}">{esc(t)}</h2>')
        items, curves = [], []
        for slot, g in have:
            runs = gpus[g][t]
            s = pooled(runs)
            tip = (f'<b>{esc(g)}</b><br>{s["avg_fps"]:.1f} fps avg<br>{s["low1_fps"]:.1f} 1% low<br>'
                   f'{s["low01_fps"]:.1f} 0.1% low<br>{len(runs)} run(s)')
            items.append((g, slot, s['avg_fps'], tip))
            curves.append((g, slot, [row for r in runs for row in r.rows]))
        body.append('<div class="charts">' + bar_chart('Average fps', items)
                    + percentile_chart('Frame-time percentiles', curves) + '</div>')
    return page(f'{title}: GPU comparison', f'{len(names)} GPUs, {len(tests)} games', ''.join(body), nav)


def index_page(gpus, title, nav, skipped):
    body = ['<table><tr><th>GPU</th><th>games</th><th>runs</th><th>driver</th><th>CPU</th></tr>']
    for g, tests in gpus.items():
        runs = [r for rs in tests.values() for r in rs]
        body.append(f'<tr><td class="l"><a href="{gpu_file(g)}">{esc(g)}</a></td><td>{len(tests)}</td>'
                    f'<td>{len(runs)}</td><td class="l">{esc(distinct(runs, "driver"))}</td>'
                    f'<td class="l">{esc(distinct(runs, "cpu"))}</td></tr>')
    body.append('</table>')
    if len(gpus) > 1:
        body.append('<p><a href="compare.html">Side by side: all GPUs per game</a></p>')
    if skipped:
        body.append('<h3>Skipped files</h3><ul>' + ''.join(f'<li>{esc(s)}</li>' for s in skipped) + '</ul>')
    return page(title, f'{len(gpus)} GPU(s)', ''.join(body), nav)


def build(folders, out, title='FRAMELOG report', skip=0.0, wheres=(), log=None, defaults=None):
    """write the report; returns the list of written file names"""
    skipped = []

    def warn(s):
        skipped.append(s)
        if log:
            log(s)
    runs = load_runs(find_csvs(folders), skip, wheres, warn, defaults)
    if not runs:
        raise SystemExit('flreport: no runs with frames found')
    gpus = by_gpu(runs)
    _FILES.clear()
    os.makedirs(out, exist_ok=True)
    links = ['<a href="index.html">index</a>'] + ([f'<a href="compare.html">compare</a>'] if len(gpus) > 1 else [])
    links += [f'<a href="{gpu_file(g)}">{esc(g)}</a>' for g in gpus]
    nav = ' · '.join(links)
    files = {'index.html': index_page(gpus, title, nav, skipped)}
    if len(gpus) > 1:
        files['compare.html'] = compare_page(gpus, title, nav)
    for g, tests in gpus.items():
        files[gpu_file(g)] = gpu_page(g, tests, title, nav)
    for name, text in files.items():
        with open(os.path.join(out, name), 'w', encoding='utf-8') as f:
            f.write(text)
    return list(files)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('folder', nargs='+', help='folders (searched recursively) or CSV files')
    ap.add_argument('-o', '--out', default='report')
    ap.add_argument('--title', default='FRAMELOG report')
    ap.add_argument('--skip', type=float, default=0, help='drop the first S seconds of every run')
    ap.add_argument('--where', action='append', default=[], metavar='KEY=VALUE', help='only runs with this metadata')
    ap.add_argument('--default', action='append', default=[], metavar='KEY=VALUE',
                    help='metadata for CSVs that lack it (older logs), e.g. --default gpu="S3 Trio64"')
    a = ap.parse_args()
    defaults = {}
    for d in a.default:
        k, _, v = d.partition('=')
        defaults[flmeta.norm_key(k)] = flmeta.clean(v)
    files = build(a.folder, a.out, a.title, a.skip, a.where, log=lambda s: print(s, file=sys.stderr),
                  defaults=defaults)
    for f in files:
        print(os.path.join(a.out, f))
    return 0


if __name__ == '__main__':
    sys.exit(main())
