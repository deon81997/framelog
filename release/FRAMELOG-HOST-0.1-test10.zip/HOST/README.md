<div align="center">

<table>
<tr>
<td align="center" width="140"><picture><img src="docs/90s/vee.gif" width="120" alt="Vee, the FRAMELOG mascot"></picture></td>
<td><b>A note from the webmaster</b> The code, the docs and all the art on this page were made by <b>Claude</b>, an AI by <a href="https://www.anthropic.com/">Anthropic</a>, working with me. This is the <b>host side</b> of <a href="https://github.com/deon81997/framelog">FRAMELOG</a>: the PC at the other end of the serial cable.</td>
</tr>
</table>

<picture><img src="docs/90s/title.gif" width="560" alt="SERIAL-BENCH"></picture>

<h2>~*~ The Other End of the Cable ~*~</h2>

<i>Logs every frame your old game PC sends, then makes stats, graphs and side-by-side GPU pages.</i>

<br><br>

<table>
<tr>
<td align="center"><picture><img src="docs/90s/cable.gif" width="300" alt="Game PC and host PC joined by a null-modem cable"></picture><br><sub>game PC (FRAMELOG) -> null-modem -> this PC</sub></td>
<td align="center"><picture><img src="docs/90s/scope.gif" width="300" alt="fllog.py drawing frame times"></picture><br><sub>(fllog.py: every frame, live)</sub></td>
</tr>
<tr>
<td align="center"><picture><img src="docs/90s/report.gif" width="300" alt="An example flreport comparison page"></picture><br><sub>(flreport.py: an example page)</sub></td>
<td align="center"><picture><img src="docs/90s/vee-hello.gif" width="300" alt="Vee says hi"></picture><br><picture><img src="docs/90s/award.gif" width="80" alt="Cool GPU Site of the Day"></picture></td>
</tr>
</table>

<picture><img src="docs/90s/construction.gif" width="260" alt="Under construction"></picture><br>
<sub>this page is ALWAYS under construction... please come back soon :-)</sub>

<br><br>

<picture><img src="docs/90s/btn-serial.gif" alt="115200 baud"></picture>
<picture><img src="docs/90s/btn-nofraps.gif" alt="No FRAPS"></picture>
<picture><img src="docs/90s/btn-3dfx.gif" alt="Tested on a Voodoo3"></picture>
<picture><img src="docs/90s/btn-gpl.gif" alt="GPL 2.0+"></picture>

<br><br>

<picture><img src="docs/90s/vee-walk.gif" width="100%" alt="Vee walking across the page"></picture>

<picture><img src="docs/90s/bar.gif" width="600" alt=""></picture>

</div>

## <picture><img src="docs/90s/star.gif" width="28" alt="*"></picture> What's in the box?? <picture><img src="docs/90s/star.gif" width="28" alt="*"></picture>

Needs Python 3 + `pip install pyserial matplotlib` (flcap.py: + `opencv-python numpy`). Works on Windows or Linux, with a real COM port or a USB-serial adapter.

| Tool | What |
|---|---|
| `fllog.py PORT -o run.csv [--label NAME] [--idle S] [--seconds N]` | logger: sends S (start), writes frames to CSV, X (stop) on Ctrl+C. A status line (frames, fps now / average, last and slowest frame time, lost) is redrawn once a second in a console; `--no-live` turns it off. PORT = COM3, /dev/ttyUSB0, or a pyserial URL (socket://127.0.0.1:4555 for QEMU) |
| `fllog.py ... --gpu G --driver D --res WxH --depth BITS --cpu C --game NAME --notes TEXT [--meta file.ini]` | run metadata, stored as `# key=value` comment lines in the CSV; the INI holds `key=value` lines (optional `[meta]` section, extra keys kept), options win over it |
| `fllog.py [PORT] --suite suite.ini [-o DIR]` | suite: several runs back to back (a batch of timedemos), one CSV per run named `game-gpu-res.csv`; a run ends at an E / new B marker or a gap (`gap` s without frames); fragments under `min_frames` are dropped; runs map to the INI's sections in order (format: `fllog.py -h`, example `suites/example.ini`); `--report DIR [--report-src results/]` builds the HTML report when the suite ends |
| `flstats.py a.csv [b.csv ...] [--png g.png] [--skip S] [--label-by gpu,res] [--group-by gpu] [--where key=value]` | stats per run (avg fps, min/max frame time, 1% / 0.1% lows = fps at the 99th / 99.9th percentile frame time) + frame-time graph; several files = machine comparison; `--group-by` adds a table pooling all runs per group |
| `flreport.py FOLDER [...] [-o report/] [--skip S] [--title T] [--where k=v] [--default k=v] [--3d]` | the **Retro GPU Shootout** pages from a folder of CSVs (searched recursively): `index.html` (summary table per GPU, the games), `game-<name>.html` per game across GPUs and CPUs (avg / 1% / 0.1% low bars, frame-time overlay, percentile curves, table, run notes), `gpu-<name>.html` (every game with its place), `compare.html` (all games x all GPUs), `run-<name>.html` per run (metadata, stats, frame times, percentiles, histogram, the CSV), `shootout.csv` + `shootout.json` exports. Self-contained folder, 90s look. `--3d` adds 90s-magazine 3D charts (columns + a frame-time waterfall per game, a games x GPUs column matrix on `compare.html`) next to the flat ones. `--default gpu="S3 Trio64"` fills metadata old CSVs lack |
| `flcap.py capture.avi -o run.csv [--fps 70.086] [--crop X,Y,W,H] [--serial run.csv] [--tears t.csv] [--multi-tear 3]` | capture analyzer: frame times from a VGA capture (Datapath etc.) of what reached the screen, row by row - tear lines, repeats, runts, adaptive noise threshold; same CSV format (source=capture) for flstats/flreport; `--serial` aligns it with the fllog CSV of the same run. For copy-to-screen games no trap sees (Heretic, Duke ScreenMode 2). Needs `pip install opencv-python numpy` |
| `flproto.py` | protocol encoder/decoder (resyncs on noise), incl. the `M` metadata record (framelog docs/PROTOCOL.md; the DOS TSR sends gpu/driver/res/depth/cpu/mode since FRAMELOG test4): game-PC metadata fills fields you left empty; a new block mid-run (the game set a mode) = a `# change@N=res=... mode=...` CSV line before frame N |

## <picture><img src="docs/90s/star.gif" width="28" alt="*"></picture> Getting Started <picture><img src="docs/90s/star.gif" width="28" alt="*"></picture>

Game coverage (what FRAMELOG can time, how, and the suite lines to repeat it): [docs/GAMES.md](docs/GAMES.md).

Tests: `python3 -m unittest discover -s tests`. Preview: `python3 tests/synth.py /tmp/syn && python3 flreport.py /tmp/syn/shootout tests/fixtures/86box-v3 -o /tmp/report`. `tests/fixtures/86box-v3/` = real FRAMELOG logs (Quake II timedemo, OpenGL + software, 86Box PII-450 Voodoo3, 2026-11-18); `synth.py` makes look-alikes (Voodoo 1/2/3, Radeon X300, GeForce 6800; marked "not measured" in their notes).

<p align="center"><img src="docs/shootout.png" width="600" alt="flreport: the Quake II page of the shootout"></p>
(3 synthetic GPU suites + look-alikes of the 86Box runs in framelog HANDOFF).

Typical run: game PC `FRAMELOG /COM:1` in AUTOEXEC (after HDPMI32I / SC55); host
`python3 fllog.py COM3 -o duke-d810.csv --label D810`; start the game; Ctrl+C when done;
`python3 flstats.py duke-d810.csv duke-p5pe.csv --png duke.png`.

Roadmap: framelog HANDOFF.md (the project's only handoff).

## <picture><img src="docs/90s/star.gif" width="28" alt="*"></picture> Thanks To My Friends <picture><img src="docs/90s/star.gif" width="28" alt="*"></picture>

[FRAMELOG](https://github.com/deon81997/framelog) (the game-PC side, the wire format and the project HANDOFF), [pySerial](https://github.com/pyserial/pyserial), [matplotlib](https://matplotlib.org/), [OpenCV](https://opencv.org/).

<div align="center">

<picture><img src="docs/90s/bar.gif" width="600" alt=""></picture>

<h3>~ Retro GPU WebRing ~</h3>

<b>[ <a href="https://github.com/deon81997/framelog">FRAMELOG</a> |
<a href="https://github.com/deon81997/NUKED-SBEMU">NUKED SB-EMU</a> |
<a href="https://86box.net/">86Box</a> ]</b>

<br><br>

<picture><img src="docs/90s/btn-ie.gif" alt="Viewed with IE 4.0"></picture>
<picture><img src="docs/90s/btn-800.gif" alt="Best viewed at 800x600"></picture>
<picture><img src="docs/90s/btn-notepad.gif" alt="Made with Notepad"></picture>
<picture><img src="docs/90s/btn-y2k.gif" alt="Y2K compliant"></picture>

<br><br>

<sub>Last updated: November 17, 2026 &nbsp;·&nbsp; art: framelog docs/90s/make90s.py (OUT90S=docs/90s ... serialbench)</sub>

</div>
