#!/usr/bin/env python3
"""flcap.py - frame times from a video capture of the game PC's screen (VGA capture card, e.g. Datapath VisionRGB).

  flcap.py capture.avi -o run.csv [--fps 70.086] [--active 0.89] [--crop X,Y,W,H] [--threshold 8] [--min-pixels 0.02]
           [--tears tears.csv] [--serial serial.csv] [--label NAME] [--gpu ...  same metadata options as fllog.py]

For games no port trap sees (copy-to-screen: Heretic, Duke ScreenMode 2) and to check what really reached the
screen. Capture at the game's own refresh (one captured frame per scan-out, e.g. 70 Hz for 320x200 / 640x400 VGA)
in a lossless or high-quality codec.

How: each captured frame is compared row by row with the one before. Every row remembers which game frame it shows.
A row that changes while it already shows the newest game frame starts a NEW game frame at that row (a tear when the
row is below the top); a row that changes while it still shows an older frame is that frame being completed
(the part above a tear, one scan-out later). New-frame time = (capture index + row / height * active) / fps,
active = visible share of the scan-out (VGA 400 of 449 lines = 0.89). Frames never visible (replaced before
scan-out reached any changed row) cannot be seen; with --serial the count of logged vs seen frames shows them.
Above the capture rate two frames can start in one scan-out: by default the later one is counted one scan-out late
(--multi-tear K also cuts at tear lines: a row-to-row jump K times bigger than any near it in the previous capture;
image edges that move fast can fake one). Rows that never change (static HUD, borders) carry no timing: a frame whose first change is low on the screen gets
a slightly late time (< 1 refresh).

Output: the fllog CSV format (source=capture) -> flstats.py / flreport.py work on it; closing comments: captures,
repeats (captures with no change), tears (new frames starting below the top margin), runts (frames shown on fewer
than 1/4 of the rows). --tears writes capture,row,frame for every frame start.
--serial: aligns the capture's frame times with a fllog CSV of the same run (cross-correlation of the frame-time
sequences) and reports the frame offset, how many logged frames were seen, and the mean frame-time difference."""
import argparse
import math
import sys

import flmeta


def to_gray_rows(frame, crop=None, width=160):
    """BGR/gray frame -> float32 gray image, columns shrunk to `width` (rows kept: they carry the timing)"""
    import cv2
    import numpy as np
    if crop:
        x, y, w, h = crop
        frame = frame[y:y + h, x:x + w]
    if frame.ndim == 3:
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    if width and frame.shape[1] > width:
        frame = cv2.resize(frame, (width, frame.shape[0]), interpolation=cv2.INTER_AREA)
    return frame.astype(np.float32)


class Analyzer:
    """feed(gray image) per captured frame; .events = [(capture, row, game_frame_no)]"""

    def __init__(self, threshold=8.0, min_pixels=0.02, top_margin=0.02, multi_tear=0.0, window=6):
        self.threshold, self.min_pixels, self.top_margin = threshold, min_pixels, top_margin
        self.multi_tear, self.window = multi_tear, window
        self.prev_rd = None
        self.noise_hist = []     # per capture: low percentile of the row medians of |diff| (= capture noise)
        self.noise = 0.0
        self.prev = None
        self.shown = None        # per row: game frame number it shows
        self.latest = 0
        self.k = -1
        self.events = []
        self.repeats = 0
        self.rows_of = {}        # game frame -> rows that changed to it (runt detection)
        self.height = None

    def feed(self, img):
        import numpy as np
        self.k += 1
        rd = np.abs(img[1:] - img[:-1]).mean(axis=1)       # row-to-row jump: rd[y-1] = between y-1 and y
        if self.prev is None:
            self.prev, self.height, self.prev_rd = img, img.shape[0], rd
            self.shown = np.zeros(self.height, dtype=np.int64)
            return
        diff = np.abs(img - self.prev)
        # capture noise: quiet rows' median |diff| over the last 100 captures (min = robust to busy frames);
        # a pixel counts when it changes by more than 5 noise sigmas (median |d| = 0.674 sigma) or the threshold
        # (from earlier captures only; capped at 3x the threshold so a game that changes every capture still counts)
        thr = max(self.threshold, min(5 * self.noise / 0.674, 3 * self.threshold))
        self.noise_hist = (self.noise_hist + [float(np.percentile(np.median(diff, axis=1), 10))])[-100:]
        self.noise = min(self.noise_hist)
        changed = (diff > thr).mean(axis=1) >= self.min_pixels
        cut = np.zeros(self.height, dtype=bool)
        if self.multi_tear:
            # tear line inside a changed area: a jump between rows that the previous capture did not have nearby
            k = self.window
            ref = np.array([self.prev_rd[max(0, i - k):i + k + 1].max() for i in range(len(rd))])
            cut[1:] = (rd > self.multi_tear * (ref + 1.0)) & (rd > 4 * self.threshold) & changed[1:] & changed[:-1]
        self.prev, self.prev_rd = img, rd
        if not changed.any():
            self.repeats += 1
            return
        run_start = None         # first row of the current run of changed rows that so far only completed a frame
        for y in np.flatnonzero(changed):
            if y == 0 or not changed[y - 1]:
                run_start = y
            if self.shown[y] >= self.latest or cut[y]:
                start = y
                if self.multi_tear and not cut[y] and run_start is not None and run_start < y:
                    # the rows above changed too with no tear line between: one new frame from the run's top
                    # (it came during the blank while the last frame was still partly old)
                    start = run_start
                    self.rows_of[self.latest] = self.rows_of.get(self.latest, 0) - (y - start)
                self.latest += 1
                self.events.append((self.k, int(start), self.latest))
                self.shown[start:y] = self.latest
                self.rows_of[self.latest] = y - start
                run_start = None
            self.shown[y] = self.latest
            self.rows_of[self.latest] = self.rows_of.get(self.latest, 0) + 1

    def frame_times(self, fps, active=0.89):
        """[(n, t_ms, frametime_ms)] from the first event on (its own time is the origin, not a frame)"""
        period = 1000.0 / fps
        ts = [(k + y / self.height * active) * period for k, y, _ in self.events]
        return [(i, ts[i] - ts[0], ts[i] - ts[i - 1]) for i in range(1, len(ts))]

    def summary(self):
        h = self.height or 1
        tears = sum(1 for _, y, _ in self.events if y > self.top_margin * h)
        runts = sum(1 for n, rows in self.rows_of.items() if rows < h / 4)
        return {'captures': self.k + 1, 'repeats': self.repeats, 'tears': tears, 'runts': runts,
                'noise': round(self.noise / 0.674, 2)}

    def near_refresh(self):
        """True when the game runs at or above the capture rate (frames may share a scan-out)"""
        busy = self.k - self.repeats
        return busy > 10 and len(self.events) >= 0.9 * busy and self.summary()['tears'] >= 0.5 * len(self.events)


def read_video(path, crop=None):
    import cv2
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise SystemExit(f"flcap: cannot open {path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 0.0

    def frames():
        while True:
            ok, f = cap.read()
            if not ok:
                break
            yield to_gray_rows(f, crop)
        cap.release()
    return fps, frames()


def align(cap_ft, ser_ft, max_lag=300, window=0):
    """best lag L (capture frame i <-> serial frame i + L) by correlation of the frame-time sequences.
    returns (lag, correlation, mean |diff| ms, overlapping frames)"""
    import numpy as np
    a, b = np.asarray(cap_ft, float), np.asarray(ser_ft, float)
    best = None
    for lag in range(-min(max_lag, len(a) - 2), min(max_lag, len(b) - 2) + 1):
        if lag >= 0:
            x, y = a, b[lag:]
        else:
            x, y = a[-lag:], b
        n = min(len(x), len(y))
        if n < max(8, window):
            continue
        x, y = x[:n], y[:n]
        sx, sy = x.std(), y.std()
        c = float(((x - x.mean()) * (y - y.mean())).mean() / (sx * sy)) if sx > 0 and sy > 0 else 0.0
        d = float(np.abs(x - y).mean())
        key = (round(c, 6), -d, n)
        if best is None or key > best[0]:
            best = (key, lag, c, d, n)
    if best is None:
        return None
    return best[1], best[2], best[3], best[4]


def write_csv(path, label, meta, rows, summary, fps, extra=None):
    with open(path, 'w') as f:
        f.write(f"# label={flmeta.clean(label)}\n")
        f.writelines(flmeta.lines(meta))
        f.write(f"# source=capture\n# capture_fps={fps:.4f}\n")
        for k, v in (extra or {}).items():
            f.write(f"# {k}={v}\n")
        f.write("frame,t_ms,frametime_ms\n")
        f.writelines(f"{n},{t:.4f},{ft:.4f}\n" for n, t, ft in rows)
        f.write(f"# frames={len(rows)}\n# lost=0\n")
        for k, v in summary.items():
            f.write(f"# {k}={v}\n")
        f.write("# stop=end\n")


def crop_arg(s):
    p = [int(v) for v in s.split(',')]
    if len(p) != 4:
        raise argparse.ArgumentTypeError('X,Y,W,H')
    return p


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('video')
    ap.add_argument('-o', '--out', required=True)
    ap.add_argument('--fps', type=float, default=0, help='capture rate (default: from the file); VGA 70 Hz = 70.086')
    ap.add_argument('--active', type=float, default=0.89, help='visible share of a scan-out (default 0.89 = 400/449)')
    ap.add_argument('--crop', type=crop_arg, help='X,Y,W,H: analyse only this part (cut overlays, borders)')
    ap.add_argument('--threshold', type=float, default=8.0, help='grey-level change of a pixel that counts (above the capture noise)')
    ap.add_argument('--min-pixels', type=float, default=0.02, help='share of a row that must change')
    ap.add_argument('--multi-tear', type=float, default=0, metavar='K',
                    help='also split frames at tear lines inside one scan-out (game fps >= capture rate); '
                         'K = how much bigger than the previous capture\'s row jump (try 3)')
    ap.add_argument('--tears', help='CSV of every frame start: capture,row,frame')
    ap.add_argument('--serial', help='fllog CSV of the same run: align and compare')
    ap.add_argument('--label', default='')
    ap.add_argument('-q', '--quiet', action='store_true')
    flmeta.add_args(ap)
    a = ap.parse_args(argv)
    fps, frames = read_video(a.video, a.crop)
    fps = a.fps or fps
    if not fps:
        raise SystemExit('flcap: the file has no frame rate, give --fps')
    an = Analyzer(a.threshold, a.min_pixels, multi_tear=a.multi_tear)
    for img in frames:
        an.feed(img)
    rows = an.frame_times(fps, a.active)
    summ = an.summary()
    extra = {}
    say = (lambda s: None) if a.quiet else (lambda s: print(s, file=sys.stderr))
    if a.serial:
        import flstats
        _, srows = flstats.load(a.serial)
        r = align([x[2] for x in rows], [x[2] for x in srows])
        if r:
            lag, c, d, n = r
            extra = {'serial': a.serial, 'serial_frames': len(srows), 'serial_lag': lag,
                     'serial_corr': f'{c:.3f}', 'serial_mean_diff_ms': f'{d:.3f}', 'serial_overlap': n}
            say(f"serial: lag {lag} frames, correlation {c:.3f}, mean |diff| {d:.2f} ms over {n} frames; "
                f"logged {len(srows)}, seen {len(rows)} (+1 origin)")
    write_csv(a.out, a.label, flmeta.from_args(a), rows, summ, fps, extra)
    if a.tears:
        with open(a.tears, 'w') as f:
            f.write("capture,row,frame\n")
            f.writelines(f"{k},{y},{n}\n" for k, y, n in an.events)
    if an.near_refresh() and not a.multi_tear:
        say("warning: the game runs near or above the capture rate - frames sharing one scan-out are merged; "
            "try --multi-tear 3")
    say(f"{len(rows)} frames from {summ['captures']} captures at {fps:.3f} fps: {summ['repeats']} repeats, "
        f"{summ['tears']} tears, {summ['runts']} runts -> {a.out}")
    return 0 if rows else 1


if __name__ == '__main__':
    sys.exit(main())
