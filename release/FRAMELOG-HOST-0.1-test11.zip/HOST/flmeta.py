"""Run metadata for FRAMELOG CSVs: GPU, driver, resolution, depth, CPU, game, notes.

Stored as CSV comment lines (`# gpu=Voodoo3 3000`) right after `# label=`, so older readers skip them.
INI files: `key=value` lines, optionally under a [meta] section; '#' / ';' start comments."""
import configparser
import re

META_KEYS = ('gpu', 'driver', 'res', 'depth', 'cpu', 'game', 'notes')
# keys fllog itself writes into the CSV; metadata may not override them
RESERVED = {'label', 'source', 'tsc_hz', 'modes', 'frames', 'lost', 'junk', 'stop', 'end_frames', 'end_lost',
            'suite', 'run'}


def clean(v):
    """one line, no surrounding blanks (a value may contain '=' and '#')"""
    return ' '.join(str(v).split())


def norm_key(k):
    return re.sub(r'[^a-z0-9_]', '_', k.strip().lower())


def parse_ini_text(text, section='meta'):
    """INI text -> {key: value}. Without any [section] the whole file is the section."""
    cp = configparser.ConfigParser(interpolation=None, inline_comment_prefixes=(';',), strict=False)
    cp.optionxform = str
    if not re.search(r'^\s*\[', text, re.M):
        text = f'[{section}]\n' + text
    cp.read_string(text)
    if not cp.has_section(section):
        return {}
    return {norm_key(k): clean(v) for k, v in cp.items(section)}


def read_ini(path, section='meta'):
    with open(path, encoding='utf-8') as f:
        return parse_ini_text(f.read(), section)


def merge(*dicts):
    """later dicts win; empty values do not override"""
    out = {}
    for d in dicts:
        for k, v in (d or {}).items():
            k = norm_key(k)
            v = clean(v) if v is not None else ''
            if v and k not in RESERVED:
                out[k] = v
    return out


def from_args(a):
    """argparse namespace with the META_KEYS options (+ optional --meta file) -> dict"""
    base = read_ini(a.meta) if getattr(a, 'meta', None) else {}
    return merge(base, {k: getattr(a, k, None) for k in META_KEYS})


def lines(meta):
    """comment lines in a stable order: known keys first, then the rest alphabetically"""
    keys = [k for k in META_KEYS if k in meta] + sorted(k for k in meta if k not in META_KEYS)
    return [f"# {k}={meta[k]}\n" for k in keys]


def add_args(ap):
    g = ap.add_argument_group('run metadata (stored as # key=value lines in the CSV)')
    g.add_argument('--gpu', help='graphics card, e.g. "Voodoo3 3000 AGP"')
    g.add_argument('--driver', help='driver / version, e.g. "3dfx 1.07.00"')
    g.add_argument('--res', help='resolution, e.g. 640x480')
    g.add_argument('--depth', help='colour depth in bits, e.g. 16')
    g.add_argument('--cpu', help='CPU, e.g. "Pentium II 450"')
    g.add_argument('--game', help='game / demo, e.g. "Duke3D 1.3D demo1"')
    g.add_argument('--notes', help='free text')
    g.add_argument('--meta', metavar='FILE.INI', help='key=value file ([meta] section optional); options above win')


def slug(s, default='x'):
    s = re.sub(r'[^A-Za-z0-9.]+', '_', str(s)).strip('_.').lower()
    return s or default


def describe(meta, keys=None, default=''):
    """label for a run: given keys joined by spaces, else meta label, else game/gpu/res"""
    if keys:
        parts = [meta.get(k, '') for k in keys]
        if any(parts):
            return ' '.join(p for p in parts if p)
        return default
    if meta.get('label'):
        return meta['label']
    parts = [meta.get(k, '') for k in ('game', 'gpu', 'res')]
    return ' '.join(p for p in parts if p) or default


def with_pc(user, pc):
    """metadata the game PC sent (M records) fills keys the user left empty; where both differ the user's value
    stays and the game PC's is kept as pc_<key> so the mismatch shows in the CSV"""
    out = dict(user)
    for k, v in (pc or {}).items():
        k, v = norm_key(k), clean(v)
        if not v or k in RESERVED or k.startswith('pc_'):
            continue
        if k not in out:
            out[k] = v
        elif out[k].lower() != v.lower():
            out['pc_' + k] = v
    return out
