"""FRAMELOG serial protocol v1 (framelog/docs/PROTOCOL.md): encoder + resyncing stream decoder."""
import struct

SYNC = 0xA5
# type -> (payload size, struct format, field names)
TYPES = {
    ord('H'): (8, '<BBIBB', ('ver', 'source', 'tsc_hz', 'modes', 'reserved')),
    ord('B'): (8, '<Q', ('tsc',)),
    ord('F'): (6, '<HI', ('frame', 'delta')),
    ord('G'): (10, '<HQ', ('frame', 'delta')),
    ord('D'): (4, '<I', ('count',)),
    ord('E'): (8, '<II', ('frames', 'lost')),
    ord('M'): (16, '<B15s', ('seq', 'text')),   # metadata text chunk (framelog docs/PROTOCOL.md)
}
META_CHUNK = 15
SOURCES = {0: 'DOS', 1: 'Win98'}


def encode(kind, **fields):
    t = ord(kind)
    size, fmt, names = TYPES[t]
    payload = struct.pack(fmt, *(fields.get(n, b'' if n == 'text' else 0) for n in names))
    return bytes([SYNC, t]) + payload + bytes([(t + sum(payload)) & 0xFF])


def encode_frame(frame, delta):
    """F record, or G when the delta needs more than 32 bits."""
    if delta >> 32:
        return encode('G', frame=frame & 0xFFFF, delta=delta)
    return encode('F', frame=frame & 0xFFFF, delta=delta)


def encode_meta(meta):
    """dict -> M records: 'key=value\\n' lines, 15-byte chunks, seq 0, 1, 2 ...; the last chunk is NUL-padded
    (a text that fills its last chunk exactly gets one more, empty chunk so the end is always seen)"""
    text = ''.join(f"{k}={v}\n" for k, v in meta.items()).encode('ascii', 'replace')
    out = b''
    for i in range(len(text) // META_CHUNK + 1):
        out += encode('M', seq=i & 0xFF, text=text[i * META_CHUNK:(i + 1) * META_CHUNK])
    return out


class MetaText:
    """collects M chunks; .meta = dict once a NUL-padded (last) chunk arrived. seq 0 starts a new block;
    a gap in seq drops the block (better no metadata than wrong metadata)."""

    def __init__(self):
        self.buf, self.next, self.meta = b'', None, {}

    def add(self, r):
        if r['seq'] == 0:
            self.buf, self.next = b'', 0
        if self.next is None or r['seq'] != self.next:
            self.next = None
            return None
        chunk = r['text']
        self.next = (self.next + 1) & 0xFF
        if b'\0' in chunk:
            self.buf += chunk.split(b'\0', 1)[0]
            self.next = None
            self.meta = {}
            for line in self.buf.decode('ascii', 'replace').splitlines():
                k, sep, v = line.partition('=')
                if sep and k.strip():
                    self.meta[k.strip().lower()] = v.strip()
            return self.meta
        self.buf += chunk
        return None


class Decoder:
    """feed(bytes) -> list of (kind, dict). Bad checksums and junk are skipped (counted in .junk)."""

    def __init__(self):
        self.buf = bytearray()
        self.junk = 0

    def feed(self, data):
        self.buf += data
        out = []
        b = self.buf
        i = 0
        while True:
            j = b.find(SYNC, i)
            if j < 0:
                self.junk += len(b) - i
                i = len(b)
                break
            self.junk += j - i
            i = j
            if i + 2 > len(b):
                break
            t = b[i + 1]
            if t not in TYPES:
                self.junk += 1
                i += 1
                continue
            size, fmt, names = TYPES[t]
            if i + 3 + size > len(b):
                break
            payload = bytes(b[i + 2:i + 2 + size])
            if (t + sum(payload)) & 0xFF != b[i + 2 + size]:
                self.junk += 1
                i += 1
                continue
            out.append((chr(t), dict(zip(names, struct.unpack(fmt, payload)))))
            i += 3 + size
        del b[:i]
        return out


class Timeline:
    """Turns decoded records into frames: list of (frame_no, t_ticks since B, delta_ticks)."""

    def __init__(self):
        self.header = None
        self.frames = []
        self.lost = 0
        self.ended = None
        self.t = 0
        self.n = 0

    def add(self, kind, r):
        if kind == 'H':
            self.header = r
        elif kind == 'B':
            self.frames, self.lost, self.ended, self.t, self.n = [], 0, None, 0, 0
        elif kind in 'FG':
            self.n += 1
            self.t += r['delta']
            self.frames.append((self.n, self.t, r['delta'], r['frame']))
        elif kind == 'D':
            self.lost += r['count']
        elif kind == 'E':
            self.ended = r

    @property
    def tsc_hz(self):
        return self.header['tsc_hz'] if self.header else None
