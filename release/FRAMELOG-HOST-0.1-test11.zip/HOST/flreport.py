#!/usr/bin/env python3
"""flreport.py - the "Retro GPU Shootout" pages from a folder of fllog.py CSVs.

  flreport.py FOLDER [FOLDER ...] [-o report/] [--skip S] [--title TEXT] [--where key=value ...] [--default key=value] [--3d]

Writes, into one folder (self-contained: no scripts, fonts or images from the net):
  index.html          the shootout home: summary table per GPU, the games, links
  game-<name>.html    one comparison page per game across GPUs and CPUs: avg fps, 1% and 0.1% low bars,
                      frame-time overlay, percentile curves, a table and the run notes
  gpu-<name>.html     summary table per GPU: every game with its stats and its place in that game's shootout
  compare.html        all games x all GPUs in one table (when there are 2+ GPUs)
  run-<name>.html     per-run detail: every metadata line, stats, frame times, percentiles, histogram, the CSV
  shootout.csv/.json  one row (object) per run with metadata + stats, for spreadsheets and scripts
  csv/                a copy of every CSV used; 90s/ the page art
Runs are grouped by the CSV metadata (fllog.py --gpu/--cpu/--game/--res/--depth or a suite):
GPU = gpu (else label, else "unknown GPU"), game = game (else label, else file name), a game's configurations =
GPU + CPU + resolution + depth. Several runs of one configuration are pooled for the summaries.
CSV folders are searched recursively; files that are not fllog CSVs are skipped with a warning.
--3d adds 90s-magazine 3D charts (extra views; the flat charts and the tables stay).
--default key=value fills metadata older CSVs lack (e.g. --default gpu="86Box S3" for pre-metadata logs)."""
import argparse
import csv
import html
import io
import json
import math
import os
import shutil
import sys

import flmeta
import flstats

# categorical slots in fixed order (validated: dataviz validate_palette.js); one slot per GPU across all pages
SERIES = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#6250d6', '#e34948']
MAX_SERIES = len(SERIES)
MAX_POINTS = 1200        # frame-time graph: more frames -> max per bucket (keeps the spikes)
ART = ('star.gif', 'bar.gif', 'vee.gif')     # copied from docs/90s next to this script, when there
HERE = os.path.dirname(os.path.abspath(__file__))
ART_DIRS = (os.path.join(HERE, 'docs', '90s'), os.path.join(HERE, '90s'))   # repo, or the FRAMELOG HOST pack

# 90s home page: teal desktop, grey bevelled windows with a blue title bar, Times headings, white sunken panels
CSS = """
body{margin:0;background:#008080;color:#000;font:15px/1.4 "Times New Roman",Times,serif}
.page{max-width:1000px;margin:0 auto;padding:16px 12px 40px}
.win{background:#c0c0c0;border:2px solid;border-color:#fff #404040 #404040 #fff;box-shadow:1px 1px 0 #000;
margin:0 0 18px;padding:0 0 10px}
.bar{background:linear-gradient(90deg,#000080,#1084d0);color:#fff;font:bold 13px Tahoma,Verdana,sans-serif;
padding:3px 6px;margin:0 0 10px;display:flex;justify-content:space-between}
.bar span.x{border:1px solid;border-color:#fff #404040 #404040 #fff;background:#c0c0c0;color:#000;
padding:0 5px;font-size:11px;line-height:13px}
.in{padding:0 12px}
h1{font:bold 30px "Times New Roman",serif;color:#000080;text-align:center;margin:4px 0 2px;
text-shadow:2px 2px 0 #808080}
h1 img,h2 img{vertical-align:middle}
h2{font:bold italic 21px "Times New Roman",serif;color:#800000;margin:4px 0 6px;text-align:center}
h3{font:bold 15px Tahoma,Verdana,sans-serif;color:#000080;margin:14px 0 4px}
.sub{text-align:center;font-style:italic;margin:0 0 8px}
.hr{display:block;margin:6px auto;max-width:100%}
.nav{font:13px Tahoma,Verdana,sans-serif;text-align:center;margin:0 0 14px;color:#fff}
.nav a{color:#ff0;font-weight:bold}.nav a:visited{color:#ffb000}
a{color:#0000ee}a:visited{color:#551a8b}
table{border-collapse:separate;border-spacing:0;background:#fff;border:2px solid;
border-color:#404040 #fff #fff #404040;margin:6px 0 10px;font:13px "Courier New",Courier,monospace}
th{background:#000080;color:#fff;font:bold 12px Tahoma,Verdana,sans-serif;padding:3px 8px;text-align:right;
white-space:nowrap}
td{padding:2px 8px;text-align:right;border-bottom:1px solid #d4d0c8;white-space:nowrap}
th:first-child,td:first-child,td.l{text-align:left}td.l{white-space:normal}
tr.best td{background:#ffffc0}td.top{font-weight:bold;color:#008000}
.muted{color:#606060}.wide{overflow-x:auto}
.panel{background:#fff;border:2px solid;border-color:#404040 #fff #fff #404040;padding:6px 8px;margin:6px 0 10px}
.charts{display:flex;flex-wrap:wrap;gap:12px}
.chart{position:relative;background:#fff;border:2px solid;border-color:#404040 #fff #fff #404040;
padding:6px 8px 4px;width:620px;max-width:100%;box-sizing:border-box}.chart.big{width:940px}
.chart .t{font:bold 13px Tahoma,Verdana,sans-serif;color:#000080;margin:0 0 2px}
.chart .n{font:11px Tahoma,Verdana,sans-serif;color:#606060;margin:2px 0 0}
svg{max-width:100%;height:auto}
svg text{fill:#000;font:11px Tahoma,Verdana,sans-serif}svg .grid{stroke:#c0c0c0;stroke-width:1;stroke-dasharray:2 2}
svg .axis{stroke:#000;stroke-width:1}svg .ser{fill:none;stroke-width:1.6;stroke-linejoin:round}
svg .xh{stroke:#000;stroke-width:1;visibility:hidden}svg .bar:hover{stroke:#000;stroke-width:1}
.legend{display:flex;flex-wrap:wrap;gap:2px 14px;font:12px Tahoma,Verdana,sans-serif;margin:0 0 4px}
.legend span{display:inline-flex;align-items:center;gap:5px}.legend i{display:inline-block;width:14px;height:10px;
border:1px solid #000}
.tip{position:absolute;pointer-events:none;background:#ffffe1;color:#000;border:1px solid #000;padding:3px 6px;
font:12px Tahoma,Verdana,sans-serif;white-space:nowrap;visibility:hidden;z-index:2}.tip i{display:inline-block;
width:8px;height:8px;border:1px solid #000;margin-right:5px}
.note{font:13px Tahoma,Verdana,sans-serif;margin:3px 0}
.foot{text-align:center;color:#fff;font:12px Tahoma,Verdana,sans-serif;margin-top:16px}
.btn{display:inline-block;background:#c0c0c0;border:2px solid;border-color:#fff #404040 #404040 #fff;
padding:2px 10px;margin:2px;font:bold 12px Tahoma,Verdana,sans-serif;color:#000;text-decoration:none}
""" + ''.join(f'.s{i + 1}{{--c:{c}}}' for i, c in enumerate(SERIES))

# crosshair + tooltip for line charts (data in the svg's data-series), tooltips for bars (data-tip)
JS = r"""
document.querySelectorAll('svg[data-series]').forEach(function(svg){
 var d=JSON.parse(svg.getAttribute('data-series')),box=svg.parentNode,tip=box.querySelector('.tip'),
 xh=svg.querySelector('.xh');
 function hide(){tip.style.visibility='hidden';xh.style.visibility='hidden';}
 svg.addEventListener('pointerleave',hide);
 svg.addEventListener('pointermove',function(e){
  var r=svg.getBoundingClientRect(),vb=svg.viewBox.baseVal,px=(e.clientX-r.left)*vb.width/r.width;
  if(px<d.x0||px>d.x1){hide();return;}
  var rows=[],xv=null;
  d.s.forEach(function(s){var p=s.p,lo=0,hi=p.length-1;if(!p.length)return;
   while(hi-lo>1){var m=(lo+hi)>>1;if(p[m][0]<px)lo=m;else hi=m;}
   var q=Math.abs(p[lo][0]-px)<Math.abs(p[hi][0]-px)?p[lo]:p[hi];if(xv===null)xv=q[2];
   rows.push('<div><i style="background:'+s.c+'"></i>'+s.n+' <b>'+q[3]+'</b></div>');});
  xh.setAttribute('x1',px);xh.setAttribute('x2',px);xh.style.visibility='visible';
  tip.innerHTML='<div>'+d.xl+' '+xv+'</div>'+rows.join('');tip.style.visibility='visible';
  var bx=box.getBoundingClientRect(),tx=e.clientX-bx.left+14;
  if(tx+tip.offsetWidth>bx.width)tx=e.clientX-bx.left-tip.offsetWidth-14;
  tip.style.left=tx+'px';tip.style.top=(e.clientY-bx.top+10)+'px';});
});
document.querySelectorAll('svg .bar').forEach(function(b){
 var box=b.closest('.chart'),tip=box.querySelector('.tip');
 b.addEventListener('pointerleave',function(){tip.style.visibility='hidden';});
 b.addEventListener('pointermove',function(e){var bx=box.getBoundingClientRect();
  tip.innerHTML=b.getAttribute('data-tip');tip.style.visibility='visible';
  tip.style.left=(e.clientX-bx.left+14)+'px';tip.style.top=(e.clientY-bx.top+10)+'px';});
});
"""

esc = html.escape
EXPORT_KEYS = ['gpu', 'cpu', 'game', 'res', 'depth', 'driver', 'api', 'notes']
STAT_KEYS = ['frames', 'seconds', 'avg_fps', 'low1_fps', 'low01_fps', 'avg_ms', 'min_ms', 'max_ms', 'p50_ms',
             'p99_ms', 'p999_ms']


# ---------- data ----------

def full_stats(rows):
    s = flstats.stats(rows)
    ft = sorted(r[2] for r in rows)
    s['p50_ms'], s['p99_ms'], s['p999_ms'] = flstats.pct(ft, 50), flstats.pct(ft, 99), flstats.pct(ft, 99.9)
    s['stutters'] = sum(1 for v in ft if v > 2 * s['p50_ms'])     # frames over twice the median
    return s


class Run:
    def __init__(self, path, meta, rows):
        self.path, self.meta, self.rows = path, meta, rows
        self.stats = full_stats(rows)
        stem = os.path.splitext(os.path.basename(path))[0]
        self.gpu = meta.get('gpu') or meta.get('label') or 'unknown GPU'
        self.cpu = meta.get('cpu', '')
        self.game = meta.get('game') or meta.get('label') or stem
        self.res = meta.get('res', '')
        self.depth = meta.get('depth', '')
        self.setting = ' · '.join(p for p in (self.res, self.depth + '-bit' if self.depth else '') if p)
        self.test = ' · '.join(p for p in (self.game, self.setting) if p)
        self.config = (self.gpu, self.cpu, self.res, self.depth)
        self.name = os.path.basename(path)
        self.id = ''             # page stem, set by build


def find_csvs(folders):
    out = []
    for f in folders:
        if os.path.isfile(f):
            out.append(f)
            continue
        for root, dirs, files in os.walk(f):
            dirs.sort()
            out += [os.path.join(root, n) for n in sorted(files) if n.lower().endswith('.csv')]
    return out


def load_runs(paths, skip=0.0, wheres=(), warn=None, defaults=None):
    runs = []
    for p in paths:
        try:
            meta, rows = flstats.load(p)
        except (ValueError, UnicodeDecodeError, OSError) as e:
            if warn:
                warn(f"skipped {p}: not a fllog CSV ({e})")
            continue
        for k, v in (defaults or {}).items():
            meta.setdefault(k, v)
        if not flstats.matches(meta, wheres):
            continue
        rows = [r for r in rows if r[1] >= skip * 1000.0]
        if not rows:
            if warn:
                warn(f"skipped {p}: no frames")
            continue
        runs.append(Run(p, meta, rows))
    return runs


def group(runs, key):
    """{key(run): [runs]} keeping first-seen order"""
    out = {}
    for r in runs:
        out.setdefault(key(r), []).append(r)
    return out


def by_gpu(runs):
    """{gpu: {test: [runs]}} keeping first-seen order"""
    return {g: group(rs, lambda r: r.test) for g, rs in group(runs, lambda r: r.gpu).items()}


def pooled(runs):
    return full_stats([row for r in runs for row in r.rows])


def distinct(runs, key):
    vals = []
    for r in runs:
        v = r.meta.get(key) if isinstance(key, str) else key(r)
        if v and v not in vals:
            vals.append(v)
    return ', '.join(vals)


# ---------- svg helpers ----------

def nice_step(span, n=5):
    if span <= 0:
        return 1.0
    raw = span / n
    mag = 10 ** math.floor(math.log10(raw))
    for m in (1, 2, 2.5, 5, 10):
        if raw <= m * mag:
            return m * mag
    return 10 * mag


def ticks(vmax, n=5):
    step = nice_step(vmax, n)
    top = step * math.ceil(vmax / step - 1e-9) if vmax > 0 else step
    k = int(round(top / step))
    return [i * step for i in range(k + 1)], top


def num(v):
    if v >= 1000:
        return f"{v:,.0f}"
    return f"{v:g}" if v == int(v) else f"{v:.1f}"


def color(slot):
    return SERIES[slot % MAX_SERIES]


def legend(items):
    """items = [(name, slot)]"""
    if len(items) < 2:
        return ''
    return '<div class="legend">' + ''.join(
        f'<span><i style="background:{color(s)}"></i>{esc(n)}</span>' for n, s in items) + '</div>'


def frame_points(rows):
    """[(t_s, ft_ms)], max per bucket above MAX_POINTS"""
    if len(rows) <= MAX_POINTS:
        return [(r[1] / 1000.0, r[2]) for r in rows]
    k = math.ceil(len(rows) / (MAX_POINTS / 2))
    out = []
    for i in range(0, len(rows), k):
        b = rows[i:i + k]
        m = max(b, key=lambda r: r[2])
        out.append((m[1] / 1000.0, m[2]))
    return out


def pct_x(p):
    """percentile -> x on a 'nines' axis: 0 % -> 0, 90 -> 1, 99 -> 2, 99.9 -> 3"""
    return -math.log10(max(1e-3, 1 - p / 100.0))


def pct_points(rows, n=240):
    ft = sorted(r[2] for r in rows)
    pts = []
    for i in range(n + 1):
        x = 3.0 * i / n
        p = 100.0 * (1 - 10 ** -x)
        pts.append((x, flstats.pct(ft, p), p))
    return pts


def chart_box(title, svg, items=(), note='', cls='chart'):
    return (f'<div class="{cls}"><div class="t">{esc(title)}</div>{legend(list(items))}{svg}'
            + (f'<div class="n">{esc(note)}</div>' if note else '') + '<div class="tip"></div></div>')


def line_chart(series, xlabel, ylabel, xticks, xfmt, tipy, xmax, ymax_hint=None, w=600, h=230, note='', step=False):
    """series = [(name, slot, [(x, y, xshow)])]; xticks = [(value, label)]"""
    ml, mr, mt, mb = 46, 12, 8, 30
    pw, ph = w - ml - mr, h - mt - mb
    ys = [p[1] for _, _, pts in series for p in pts]
    ymax = ymax_hint or (max(ys) if ys else 1)
    yt, ytop = ticks(ymax)
    clipped = any(y > ytop for y in ys)
    X = lambda x: ml + pw * (x / xmax if xmax else 0)       # noqa: E731
    Y = lambda y: mt + ph * (1 - min(y, ytop) / ytop)       # noqa: E731
    o = [f'<svg viewBox="0 0 {w} {h}" width="{w}" height="{h}" role="img" aria-label="{esc(ylabel)} by {esc(xlabel)}"']
    data = {'x0': ml, 'x1': ml + pw, 'xl': xlabel, 's': []}
    for name, slot, pts in series:
        data['s'].append({'n': esc(name), 'c': color(slot),
                          'p': [[round(X(p[0]), 1), 0, xfmt(p), tipy(p)] for p in pts]})
    o[0] += f" data-series='{esc(json.dumps(data, separators=(',', ':')), quote=True)}'>"
    for v in yt:
        o.append(f'<line class="grid" x1="{ml}" x2="{ml + pw}" y1="{Y(v):.1f}" y2="{Y(v):.1f}"/>'
                 f'<text x="{ml - 6}" y="{Y(v) + 4:.1f}" text-anchor="end">{num(v)}</text>')
    for v, lab in xticks:
        o.append(f'<text x="{X(v):.1f}" y="{mt + ph + 16}" text-anchor="middle">{esc(lab)}</text>')
    o.append(f'<line class="axis" x1="{ml}" x2="{ml}" y1="{mt}" y2="{mt + ph}"/>'
             f'<line class="axis" x1="{ml}" x2="{ml + pw}" y1="{mt + ph}" y2="{mt + ph}"/>')
    o.append(f'<text x="{ml + pw}" y="{h - 2}" text-anchor="end">{esc(xlabel)}</text>')
    o.append(f'<text transform="translate(10,{mt + ph / 2:.0f}) rotate(-90)" text-anchor="middle">{esc(ylabel)}</text>')
    for name, slot, pts in series:
        if step:    # a frame's time covers the interval that ends at its timestamp (steps-pre)
            xy, prev = [], 0.0
            for p in pts:
                xy += [(prev, p[1]), (p[0], p[1])]
                prev = p[0]
        else:
            xy = [(p[0], p[1]) for p in pts]
        d = ' '.join(f'{X(x):.1f},{Y(y):.1f}' for x, y in xy)
        o.append(f'<polyline class="ser" style="stroke:{color(slot)}" points="{d}"><title>{esc(name)}</title></polyline>')
    o.append(f'<line class="xh" x1="0" x2="0" y1="{mt}" y2="{mt + ph}"/></svg>')
    if clipped:
        note = (note + ' ' if note else '') + f'Spikes above {num(ytop)} ms are cut at the top; the tables have the real maximum.'
    return ''.join(o), note


def frametime_chart(title, runs_named):
    """runs_named = [(name, slot, rows)] - the frame times of several runs on one time axis"""
    series, xmax, p99s, bucketed = [], 0.0, [], False
    for name, slot, rows in runs_named:
        pts = frame_points(rows)
        bucketed |= len(pts) < len(rows)
        series.append((name, slot, [(t, ft, None) for t, ft in pts]))
        xmax = max(xmax, rows[-1][1] / 1000.0)
        p99s.append(flstats.pct(sorted(r[2] for r in rows), 99))
    st = nice_step(xmax, 6)
    xt = [(i * st, num(i * st)) for i in range(int(xmax / st) + 1)]
    svg, note = line_chart(series, 'time (s)', 'frame time (ms)', xt, lambda p: f'{p[0]:.2f} s',
                           lambda p: f'{p[1]:.2f} ms', xmax or 1, 4 * max(p99s),
                           note='Slowest frame per time slice shown.' if bucketed else '', step=True)
    return chart_box(title, svg, [(n, s) for n, s, _ in runs_named], note)


def percentile_chart(title, runs_named):
    series = [(name, slot, pct_points(rows)) for name, slot, rows in runs_named]
    xt = [(0, '0'), (pct_x(50), '50'), (1, '90'), (2, '99'), (3, '99.9')]
    ymax = max(p[1] for _, _, pts in series for p in pts)
    p99 = max(flstats.pct(sorted(r[2] for r in rows), 99) for _, _, rows in runs_named)
    ymax = min(ymax, 4 * p99)          # one load gap must not flatten every curve (cut, with a note)
    svg, note = line_chart(series, 'percentile', 'frame time (ms)', xt, lambda p: f'{p[2]:.2f} %',
                           lambda p: f'{p[1]:.2f} ms ({1000.0 / p[1]:.1f} fps)' if p[1] else '-', 3, ymax,
                           note='Frame time at each percentile; 99 = the 1% low, 99.9 = the 0.1% low. Lower is better.')
    return chart_box(title, svg, [(n, s) for n, s, _ in runs_named], note)


LOWS = (('avg_fps', 'avg', 1.0), ('low1_fps', '1% low', 0.62), ('low01_fps', '0.1% low', 0.34))


def lows_chart(title, groups, w=600):
    """groups = [(name, slot, stats, runs)]: per configuration three horizontal bars (avg, 1% low, 0.1% low) on one
    fps scale, the configuration's colour fading from avg to 0.1% low, the value at each bar's end"""
    if not groups:
        return ''
    lab_w, tag_w, bh, gap, ggap, mt = 190, 52, 13, 2, 12, 4
    x0 = lab_w + tag_w
    pw = w - x0 - 46
    vmax = max(s['avg_fps'] for _, _, s, _ in groups) or 1
    _, top = ticks(vmax, 5)
    gh = 3 * bh + 2 * gap
    h = mt + len(groups) * (gh + ggap) + 18
    o = [f'<svg viewBox="0 0 {w} {h}" width="{w}" height="{h}" role="img" aria-label="{esc(title)}">']
    for v in ticks(vmax, 5)[0]:
        x = x0 + pw * v / top
        o.append(f'<line class="grid" x1="{x:.1f}" x2="{x:.1f}" y1="{mt}" y2="{h - 18}"/>'
                 f'<text x="{x:.1f}" y="{h - 5}" text-anchor="middle">{num(v)}</text>')
    for i, (name, slot, s, n) in enumerate(groups):
        y = mt + i * (gh + ggap)
        head, _, rest = name.partition(' · ')
        lines = [head] + ([rest] if rest else [])
        lines = [t if len(t) <= 30 else t[:29] + '…' for t in lines]
        for k, t in enumerate(lines):
            yy = y + gh / 2 + 4 + (k - (len(lines) - 1) / 2) * 13
            o.append(f'<text x="{lab_w - 8}" y="{yy:.1f}" text-anchor="end"'
                     f'{" style=\"font-weight:bold\"" if k == 0 else ""}>{esc(t)}<title>{esc(name)}</title></text>')
        tip = (f'<b>{esc(name)}</b><br>{s["avg_fps"]:.1f} fps avg<br>{s["low1_fps"]:.1f} 1% low<br>'
               f'{s["low01_fps"]:.1f} 0.1% low<br>{n} run(s), {s["frames"]} frames')
        for j, (key, tag, op) in enumerate(LOWS):
            yy = y + j * (bh + gap)
            v = s[key]
            bw = max(1.0, pw * v / top)
            o.append(f'<text x="{x0 - 4}" y="{yy + bh - 3}" text-anchor="end">{tag}</text>'
                     f'<rect class="bar" x="{x0}" y="{yy}" width="{bw:.1f}" height="{bh}" '
                     f'style="fill:{color(slot)};fill-opacity:{op};stroke:#000;stroke-width:.6" '
                     f'data-tip="{esc(tip, quote=True)}"/>'
                     f'<text x="{x0 + bw + 4:.1f}" y="{yy + bh - 3}">{v:.1f}</text>')
    o.append(f'<line class="axis" x1="{x0}" x2="{x0}" y1="{mt - 2}" y2="{h - 18}"/></svg>')
    return chart_box(title, ''.join(o), [], 'fps, higher is better: per configuration the average, the 1% low and '
                     'the 0.1% low (fps at the slowest 1% / 0.1% of frames).')


def hist_chart(title, rows, slot=0, w=600, h=200):
    """frame-time histogram: share of frames per frame-time bucket, up to twice the 99th percentile"""
    ft = sorted(r[2] for r in rows)
    hi = min(ft[-1], 2 * flstats.pct(ft, 99)) or 1
    st = nice_step(hi, 20)
    nb = max(1, int(math.ceil(hi / st)))
    counts = [0] * (nb + 1)
    for v in ft:
        counts[min(nb, int(v // st))] += 1
    share = [100.0 * c / len(ft) for c in counts]
    ml, mr, mt, mb = 46, 12, 8, 30
    pw, ph = w - ml - mr, h - mt - mb
    yt, ytop = ticks(max(share) or 1, 4)
    bw = pw / (nb + 1)
    o = [f'<svg viewBox="0 0 {w} {h}" width="{w}" height="{h}" role="img" aria-label="{esc(title)}">']
    for v in yt:
        y = mt + ph * (1 - v / ytop)
        o.append(f'<line class="grid" x1="{ml}" x2="{ml + pw}" y1="{y:.1f}" y2="{y:.1f}"/>'
                 f'<text x="{ml - 6}" y="{y + 4:.1f}" text-anchor="end">{num(v)}</text>')
    for i, v in enumerate(share):
        bh = ph * v / ytop
        lo = i * st
        lab = f'{num(lo)}-{num(lo + st)} ms' if i < nb else f'≥ {num(lo)} ms'
        o.append(f'<rect class="bar" x="{ml + i * bw + 1:.1f}" y="{mt + ph - bh:.1f}" width="{max(1.0, bw - 2):.1f}" '
                 f'height="{bh:.1f}" style="fill:{color(slot)};stroke:#000;stroke-width:.6" '
                 f'data-tip="{esc(f"{lab}<br><b>{counts[i]}</b> frames ({v:.1f} %)", quote=True)}"/>')
    every = max(1, (nb + 1) // 8)
    for i in range(0, nb + 1, every):
        o.append(f'<text x="{ml + i * bw:.1f}" y="{mt + ph + 16}" text-anchor="middle">{num(i * st)}</text>')
    o.append(f'<line class="axis" x1="{ml}" x2="{ml}" y1="{mt}" y2="{mt + ph}"/>'
             f'<line class="axis" x1="{ml}" x2="{ml + pw}" y1="{mt + ph}" y2="{mt + ph}"/>'
             f'<text x="{ml + pw}" y="{h - 2}" text-anchor="end">frame time (ms)</text>'
             f'<text transform="translate(10,{mt + ph / 2:.0f}) rotate(-90)" text-anchor="middle">% of frames</text></svg>')
    return chart_box(title, ''.join(o), [], f'Buckets of {num(st)} ms; the last one holds everything slower.')


# ---------- 3D (--3d): 90s-magazine charts in oblique projection; extra views, the flat charts and tables stay ----------

def tint(c, f):
    """mix colour c with white (f > 0) or black (f < 0)"""
    r, g, b = (int(c[i:i + 2], 16) for i in (1, 3, 5))
    t = 255 if f > 0 else 0
    f = abs(f)
    return '#%02x%02x%02x' % tuple(round(v + (t - v) * f) for v in (r, g, b))


def walls3d(o, ml, base, fw, nz, dx, dy, ph, yt, top, ylabel):
    """floor, left wall and back wall with value grid lines; fw = front width of the floor"""
    D, E = nz * dx, nz * dy
    pt = lambda pts: ' '.join(f'{x:.1f},{y:.1f}' for x, y in pts)          # noqa: E731
    o.append(f'<polygon points="{pt([(ml, base), (ml + fw, base), (ml + fw + D, base - E), (ml + D, base - E)])}" '
             f'style="fill:#b8b8b8;stroke:#000;stroke-width:.6"/>'
             f'<polygon points="{pt([(ml, base), (ml + D, base - E), (ml + D, base - E - ph), (ml, base - ph)])}" '
             f'style="fill:#d4d0c8;stroke:#000;stroke-width:.6"/>'
             f'<polygon points="{pt([(ml + D, base - E), (ml + fw + D, base - E), (ml + fw + D, base - E - ph), (ml + D, base - E - ph)])}" '
             f'style="fill:#e8e8e8;stroke:#000;stroke-width:.6"/>')
    for v in yt[1:]:
        y = ph * v / top
        o.append(f'<polyline class="grid" points="{pt([(ml, base - y), (ml + D, base - E - y), (ml + fw + D, base - E - y)])}" '
                 f'style="fill:none"/><text x="{ml - 6}" y="{base - y + 4:.1f}" text-anchor="end">{num(v)}</text>')
    o.append(f'<text x="{ml - 6}" y="{base + 4:.1f}" text-anchor="end">0</text>'
             f'<text transform="translate({ml - 34:.0f},{base - ph / 2:.0f}) rotate(-90)" text-anchor="middle">{esc(ylabel)}</text>')


def columns3d(title, xlabels, zlabels, cells, ylabel, note, w=920, ph=230, mr=None):
    """3D column chart: x = xlabels, depth = zlabels (index 0 in front), cells[z][x] = (value, colour, tip) or None"""
    nx, nz = len(xlabels), len(zlabels)
    if not nx or not nz:
        return ''
    mr = mr if mr is not None else 8 + 7 * max(len(z) for z in zlabels)
    step = min(30.0, 170.0 / nz)
    dx, dy = step * 0.85, step * 0.5
    ml, mt = 48 + min(150, 5.3 * max(min(len(x), 30) for x in xlabels)), 8      # room for the slanted labels
    fw = w - ml - mr - nz * dx
    cw = fw / nx
    bw = cw * 0.55
    tdx, tdy = min(dx * 0.65, (cw - bw) * 0.9), dy * 0.65
    vmax = max((c[0] for row in cells for c in row if c), default=1) or 1
    yt, top = ticks(vmax, 5)
    base = mt + nz * dy + ph
    h = base + 96
    o = [f'<svg viewBox="0 0 {w} {h:.0f}" width="{w}" height="{h:.0f}" role="img" aria-label="{esc(title)}" data-3d="1">']
    walls3d(o, ml, base, fw, nz, dx, dy, ph, yt, top, ylabel)
    pt = lambda pts: ' '.join(f'{x:.1f},{y:.1f}' for x, y in pts)          # noqa: E731
    for k in range(nz - 1, -1, -1):                   # back to front, left to right
        for i in range(nx):
            c = cells[k][i]
            if not c:
                continue
            v, col, tip = c
            H = ph * v / top
            X = ml + i * cw + (cw - bw) / 2 + k * dx
            Y = base - k * dy
            t = esc(tip, quote=True)
            o.append(f'<g class="bar" data-tip="{t}" style="stroke:#000;stroke-width:.6">'
                     f'<polygon points="{pt([(X + bw, Y), (X + bw, Y - H), (X + bw + tdx, Y - H - tdy), (X + bw + tdx, Y - tdy)])}" style="fill:{tint(col, -0.35)}"/>'
                     f'<polygon points="{pt([(X, Y - H), (X + bw, Y - H), (X + bw + tdx, Y - H - tdy), (X + tdx, Y - H - tdy)])}" style="fill:{tint(col, 0.35)}"/>'
                     f'<rect x="{X:.1f}" y="{Y - H:.1f}" width="{bw:.1f}" height="{H:.1f}" style="fill:{col}"/></g>')
        o.append(f'<text x="{ml + fw + k * dx + 4:.1f}" y="{base - k * dy - dy * 0.2:.1f}">{esc(zlabels[k])}</text>')
    for i, lab in enumerate(xlabels):          # slanted labels under the front row, 90s spreadsheet style
        t = lab if len(lab) <= 30 else lab[:29] + '…'
        x = ml + i * cw + cw / 2 + 4
        o.append(f'<text transform="translate({x:.1f},{base + 10:.1f}) rotate(-28)" text-anchor="end">'
                 f'{esc(t)}<title>{esc(lab)}</title></text>')
    o.append('</svg>')
    return chart_box(title, ''.join(o), [], note, 'chart big')


def lows3d(title, groups):
    """groups = [(name, slot, stats, runs)] -> configurations across, 0.1% low / 1% low / avg from front to back"""
    metrics = list(reversed(LOWS))                          # front: 0.1% low (shortest), back: avg
    cells = []
    for key, tag, _ in metrics:
        f = {'avg_fps': 0.0, 'low1_fps': 0.3, 'low01_fps': 0.55}[key]
        cells.append([(s[key], tint(color(slot), f), f'<b>{esc(name)}</b><br>{tag}: {s[key]:.1f} fps')
                      for name, slot, s, _ in groups])
    return columns3d(title, [g[0] for g in groups], [m[1] for m in metrics], cells, 'fps',
                     'fps, higher is better. Front row the 0.1% low, then the 1% low, the average at the back. '
                     '3D bars look nice but are hard to read exactly: the table has the numbers.', mr=70)


def waterfall3d(title, runs_named, w=920, ph=220):
    """frame times of several runs as ridges one behind the other (first in front)"""
    nz = len(runs_named)
    if not nz:
        return ''
    step = min(26.0, 160.0 / nz)
    dx, dy = step * 0.9, step * 0.55
    ml, mt, mr = 48, 8, 12 + 6 * min(34, max(len(n) for n, _, _ in runs_named))
    fw = w - ml - mr - nz * dx
    xmax = max(rows[-1][1] for _, _, rows in runs_named) / 1000.0 or 1
    p99 = max(flstats.pct(sorted(r[2] for r in rows), 99) for _, _, rows in runs_named)
    yt, top = ticks(4 * p99, 4)
    base = mt + nz * dy + ph
    h = base + 30
    o = [f'<svg viewBox="0 0 {w} {h:.0f}" width="{w}" height="{h:.0f}" role="img" aria-label="{esc(title)}" data-3d="1">']
    walls3d(o, ml, base, fw, nz, dx, dy, ph, yt, top, 'frame time (ms)')
    clipped = False
    for k in range(nz - 1, -1, -1):
        name, slot, rows = runs_named[k]
        ox, oy = k * dx, base - k * dy
        pts = frame_points(rows)
        pts = [(0.0, pts[0][1])] + pts
        clipped |= any(ft > top for _, ft in pts)
        line = [(ml + ox + fw * t / xmax, oy - ph * min(ft, top) / top) for t, ft in pts]
        poly = [(line[0][0], oy)] + line + [(line[-1][0], oy)]
        s = flstats.stats(rows)
        tip = (f'<b>{esc(name)}</b><br>{s["avg_fps"]:.1f} fps avg<br>{s["low1_fps"]:.1f} 1% low<br>'
               f'max {s["max_ms"]:.1f} ms')
        o.append(f'<polygon class="bar" points="{" ".join(f"{x:.1f},{y:.1f}" for x, y in poly)}" '
                 f'style="fill:{tint(color(slot), 0.45)};fill-opacity:.92;stroke:{tint(color(slot), -0.3)};stroke-width:1" '
                 f'data-tip="{esc(tip, quote=True)}"/>'
                 f'<text x="{ml + fw + ox + 4:.1f}" y="{oy - 2:.1f}">{esc(name if len(name) <= 34 else name[:33] + "…")}</text>')
    st = nice_step(xmax, 6)
    for i in range(int(xmax / st) + 1):
        o.append(f'<text x="{ml + fw * i * st / xmax:.1f}" y="{base + 14:.1f}" text-anchor="middle">{num(i * st)}</text>')
    o.append(f'<text x="{ml + fw:.1f}" y="{h - 2:.1f}" text-anchor="end">time (s)</text></svg>')
    note = 'Frame time over the run, one ridge per configuration, fastest in front.'
    if clipped:
        note += f' Spikes above {num(top)} ms are cut at the top.'
    return chart_box(title, ''.join(o), [], note, 'chart big')


# ---------- pages ----------

def window(title, body, wid=''):
    idattr = f' id="{wid}"' if wid else ''
    return (f'<div class="win"{idattr}><div class="bar"><span>{esc(title)}</span><span class="x">x</span></div>'
            f'<div class="in">{body}</div></div>')


def heading(text):
    return f'<h2><img src="90s/star.gif" width="20" alt="*"> {esc(text)} <img src="90s/star.gif" width="20" alt="*"></h2>'


def page(title, sub, windows, nav):
    return (f'<!DOCTYPE html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" '
            f'content="width=device-width,initial-scale=1"><title>{esc(title)}</title><style>{CSS}</style></head>'
            f'<body><div class="page"><h1 style="color:#ff0;text-shadow:3px 3px 0 #000">~*~ {esc(title)} ~*~</h1>'
            f'<p class="sub" style="color:#fff">{sub}</p><div class="nav">{nav}</div>'
            f'<img class="hr" src="90s/bar.gif" width="600" alt="">'
            f'{"".join(windows)}'
            f'<p class="foot">made by flreport.py (serial-bench) from FRAMELOG logs · best viewed at 800x600 · '
            f'<a href="shootout.csv" style="color:#ff0">CSV</a> · <a href="shootout.json" style="color:#ff0">JSON</a>'
            f'</p></div><script>{JS}</script></body></html>\n')


class Names:
    """unique page names per report"""
    def __init__(self):
        self.used, self.map = set(), {}

    def get(self, kind, key, text):
        if (kind, key) not in self.map:
            stem, i = kind + '-' + flmeta.slug(text, 'unknown'), 2
            name = stem
            while name in self.used:
                name, i = f'{stem}-{i}', i + 1
            self.used.add(name)
            self.map[(kind, key)] = name
        return self.map[(kind, key)] + '.html'


STAT_HEAD = ('<tr><th>{}</th><th>avg fps</th><th>1% low</th><th>0.1% low</th><th>frames</th><th>seconds</th>'
             '<th>min ms</th><th>max ms</th>{}</tr>')


def stat_cells(s, win=None):
    w = ' class="top"' if win else ''
    return (f'<td{w}>{s["avg_fps"]:.1f}</td><td>{s["low1_fps"]:.1f}</td><td>{s["low01_fps"]:.1f}</td>'
            f'<td>{s["frames"]}</td><td>{s["seconds"]:.1f}</td><td>{s["min_ms"]:.2f}</td><td>{s["max_ms"]:.2f}</td>')


class Report:
    def __init__(self, runs, title, three_d=False):
        self.runs, self.title, self.three_d = runs, title, three_d
        self.names = Names()
        self.gpus = by_gpu(runs)
        self.slots = {g: i for i, g in enumerate(self.gpus)}     # one colour per GPU on every page
        self.games = group(runs, lambda r: r.game)
        for r in runs:
            r.id = self.names.get('run', id(r), f'{r.gpu}-{r.game}-{r.setting}')[:-5]
        # ranking per test: configurations by pooled avg fps
        self.rank = {}
        for test, rs in group(runs, lambda r: r.test).items():
            cfgs = group(rs, lambda r: (r.gpu, r.cpu))
            order = sorted(cfgs, key=lambda c: -pooled(cfgs[c])['avg_fps'])
            for i, c in enumerate(order):
                self.rank[(test,) + c] = (i + 1, len(order))

    def gpu_file(self, g):
        return self.names.get('gpu', g, g)

    def game_file(self, game):
        return self.names.get('game', game, game)

    def nav(self):
        links = ['<a href="index.html">Home</a>'] + (['<a href="compare.html">All games</a>'] if len(self.gpus) > 1 else [])
        links += [f'<a href="{self.game_file(g)}">{esc(g)}</a>' for g in self.games]
        return ' | '.join(links) + '<br>' + ' | '.join(f'<a href="{self.gpu_file(g)}">{esc(g)}</a>' for g in self.gpus)

    def configs(self, runs):
        """[(label, slot, [runs])] - one per GPU+CPU+res+depth; label shows CPU / setting only when they vary"""
        cfgs = group(runs, lambda r: r.config)
        many_cpu = len({c[1] for c in cfgs}) > 1
        many_set = len({c[2:] for c in cfgs}) > 1
        out, used = [], set()
        for c, rs in cfgs.items():
            r = rs[0]
            parts = [r.gpu] + ([r.cpu or '?'] if many_cpu else []) + ([r.setting or '?'] if many_set else [])
            slot = self.slots[r.gpu]
            while slot in used and len(used) < MAX_SERIES:
                slot = (slot + 1) % MAX_SERIES
            used.add(slot)
            out.append((' · '.join(parts), slot, rs))
        return out

    def notes_list(self, runs):
        items = []
        for r in runs:
            bits = [f'{k}: {esc(r.meta[k])}' for k in ('driver', 'api', 'source', 'lost') if r.meta.get(k)]
            if r.stats['stutters']:
                bits.append(f'{r.stats["stutters"]} frames over twice the median')
            note = r.meta.get('notes', '')
            items.append(f'<li><a href="{r.id}.html">{esc(r.name)}</a> ({esc(r.gpu)}{", " + esc(r.cpu) if r.cpu else ""})'
                         + (f' - <b>{esc(note)}</b>' if note else '') + (f' <span class="muted">[{"; ".join(bits)}]</span>' if bits else '')
                         + '</li>')
        return '<ul class="note">' + ''.join(items) + '</ul>'

    # --- pages
    def game_page(self, game, runs):
        cfgs = self.configs(runs)
        stats = [(lab, slot, pooled(rs), rs) for lab, slot, rs in cfgs]
        stats.sort(key=lambda t: -t[2]['avg_fps'])
        shown = stats[:MAX_SERIES]
        wins = []
        best = stats[0]
        intro = (f'<p class="note"><b>{len(cfgs)}</b> configuration(s), <b>{len(runs)}</b> run(s). Top score: '
                 f'<b>{esc(best[0])}</b> with <b>{best[2]["avg_fps"]:.1f} fps</b> average, '
                 f'{best[2]["low1_fps"]:.1f} fps 1% low.</p>')
        wins.append(window(f'{game} - fps', intro + '<div class="charts">'
                           + lows_chart('Average, 1% low and 0.1% low', [(lab, slot, s, len(rs)) for lab, slot, s, rs in shown])
                           + '</div>'))
        named = [(lab, slot, [row for r in rs for row in r.rows] if len(rs) == 1 else rs[0].rows)
                 for lab, slot, _, rs in shown]
        curves = [(lab, slot, [row for r in rs for row in r.rows]) for lab, slot, _, rs in shown]
        extra = ' (first run of each configuration)' if any(len(rs) > 1 for *_, rs in shown) else ''
        wins.append(window(f'{game} - frame times', '<div class="charts">'
                           + frametime_chart('Frame-time overlay' + extra, named)
                           + percentile_chart('Frame-time percentiles (all runs pooled)', curves) + '</div>'
                           + (f'<p class="muted">Charts show the {MAX_SERIES} fastest configurations; the table has all '
                              f'{len(stats)}.</p>' if len(stats) > MAX_SERIES else '')))
        if self.three_d:
            wins.append(window(f'{game} - 3D view', '<div class="charts">'
                               + lows3d('3D: average, 1% low and 0.1% low', shown)
                               + waterfall3d('3D: frame-time waterfall' + extra, named) + '</div>'))
        t = ['<div class="wide"><table>', STAT_HEAD.format('#</th><th style="text-align:left">configuration',
                                                           '<th>runs</th><th>driver</th><th>run pages</th>')]
        for i, (lab, slot, s, rs) in enumerate(stats):
            links = ' '.join(f'<a href="{r.id}.html">{j + 1}</a>' for j, r in enumerate(rs))
            t.append(f'<tr{" class=best" if i == 0 else ""}><td>{i + 1}</td><td class="l"><i style="display:inline-block;'
                     f'width:10px;height:10px;border:1px solid #000;background:{color(slot)}"></i> '
                     f'<a href="{self.gpu_file(rs[0].gpu)}">{esc(lab)}</a></td>{stat_cells(s, i == 0)}<td>{len(rs)}</td>'
                     f'<td class="l">{esc(distinct(rs, "driver"))}</td><td class="l">{links}</td></tr>')
        t.append('</table></div>')
        wins.append(window(f'{game} - the table', ''.join(t)))
        wins.append(window(f'{game} - run notes', self.notes_list(runs)))
        sub = 'one game, every GPU and CPU it was run on'
        return page(f'{game}', sub, wins, self.nav())

    def gpu_page(self, g, tests):
        allruns = [r for rs in tests.values() for r in rs]
        info = []
        for k, lab in (('driver', 'Driver'), ('cpu', 'CPU'), ('api', 'API'), ('source', 'Logged from')):
            v = distinct(allruns, k)
            if v:
                info.append(f'<b>{lab}:</b> {esc(v)}')
        t = ['<div class="wide"><table>', STAT_HEAD.format('game', '<th>CPU</th><th>runs</th><th>place</th>')]
        for test, runs in tests.items():
            for cpu, rs in group(runs, lambda r: r.cpu).items():
                place, of = self.rank[(test, g, cpu)]
                pl = f'#{place} of {of}' if of > 1 else '-'
                t.append(f'<tr{" class=best" if place == 1 and of > 1 else ""}><td class="l">'
                         f'<a href="{self.game_file(rs[0].game)}">{esc(test)}</a></td>{stat_cells(pooled(rs))}'
                         f'<td class="l">{esc(cpu)}</td><td>{len(rs)}</td><td>{pl}</td></tr>')
        t.append('</table></div><p class="muted">place = rank by average fps among the GPU+CPU pairs that ran '
                 'the same game at the same setting.</p>')
        runs_t = ['<div class="wide"><table>', STAT_HEAD.format('run', '<th>lost</th><th>notes</th>')]
        for r in allruns:
            runs_t.append(f'<tr><td class="l"><a href="{r.id}.html">{esc(r.name)}</a></td>{stat_cells(r.stats)}'
                          f'<td>{esc(r.meta.get("lost", "?"))}</td><td class="l">{esc(r.meta.get("notes", ""))}</td></tr>')
        runs_t.append('</table></div>')
        wins = [window(f'{g} - summary', '<p class="note">' + ' · '.join(info) + '</p>' + ''.join(t)),
                window(f'{g} - every run', ''.join(runs_t))]
        return page(g, 'summary table for one graphics card', wins, self.nav())

    def run_page(self, r):
        s = r.stats
        meta = ''.join(f'<tr><td class="l">{esc(k)}</td><td class="l">{esc(v)}</td></tr>' for k, v in r.meta.items())
        st = (f'<table><tr><th>stat</th><th>value</th></tr>'
              + ''.join(f'<tr><td class="l">{lab}</td><td>{val}</td></tr>' for lab, val in (
                  ('frames', s['frames']), ('seconds', f'{s["seconds"]:.2f}'), ('average fps', f'{s["avg_fps"]:.2f}'),
                  ('1% low fps', f'{s["low1_fps"]:.2f}'), ('0.1% low fps', f'{s["low01_fps"]:.2f}'),
                  ('average ms', f'{s["avg_ms"]:.2f}'), ('median ms', f'{s["p50_ms"]:.2f}'),
                  ('min ms', f'{s["min_ms"]:.2f}'), ('max ms', f'{s["max_ms"]:.2f}'),
                  ('99th pct ms', f'{s["p99_ms"]:.2f}'), ('99.9th pct ms', f'{s["p999_ms"]:.2f}'),
                  ('frames over 2x median', s['stutters']))) + '</table>')
        slot = self.slots[r.gpu]
        top = (f'<p class="note"><b>{esc(r.gpu)}</b>{" · " + esc(r.cpu) if r.cpu else ""} · '
               f'<a href="{self.game_file(r.game)}">{esc(r.test)}</a> · '
               f'<a href="csv/{r.id}.csv">download the CSV</a></p>'
               + (f'<p class="note">Notes: <b>{esc(r.meta["notes"])}</b></p>' if r.meta.get('notes') else '')
               + '<div class="charts"><div>' + st + '</div><div><table><tr><th>metadata</th><th>value</th></tr>'
               + (meta or '<tr><td class="l muted" colspan="2">none (pre-metadata log)</td></tr>') + '</table></div></div>')
        wins = [window(f'{r.name}', top),
                window('frame times', '<div class="charts">' + frametime_chart('Frame time', [(r.name, slot, r.rows)])
                       + percentile_chart('Frame-time percentiles', [(r.name, slot, r.rows)])
                       + hist_chart('Frame-time histogram', r.rows, slot) + '</div>')]
        return page(f'Run: {r.game}', f'one run on {esc(r.gpu)}', wins, self.nav())

    def compare_page(self):
        names = list(self.gpus)
        tests = list(group(self.runs, lambda r: r.test))
        head = ''.join(f'<th colspan="3"><a style="color:#ff0" href="{self.gpu_file(g)}">{esc(g)}</a></th>' for g in names)
        sub_head = '<th>avg</th><th>1%</th><th>0.1%</th>' * len(names)
        t = ['<p class="note">fps: average, 1% low, 0.1% low (all runs and CPUs of a GPU pooled); green = fastest.</p>',
             f'<div class="wide"><table><tr><th></th>{head}</tr><tr><th>game</th>{sub_head}</tr>']
        for test in tests:
            vals = {g: pooled(self.gpus[g][test]) for g in names if test in self.gpus[g]}
            best = max(vals, key=lambda g: vals[g]['avg_fps'])
            game = next(r.game for r in self.runs if r.test == test)
            cells = []
            for g in names:
                s = vals.get(g)
                if s:
                    w = ' class="top"' if g == best and len(vals) > 1 else ''
                    cells.append(f'<td{w}>{s["avg_fps"]:.1f}</td><td>{s["low1_fps"]:.1f}</td><td>{s["low01_fps"]:.1f}</td>')
                else:
                    cells.append('<td class="muted">-</td>' * 3)
            t.append(f'<tr><td class="l"><a href="{self.game_file(game)}">{esc(test)}</a></td>{"".join(cells)}</tr>')
        t.append('</table></div>')
        if self.three_d:
            order = sorted(names, key=lambda g: -sum(pooled(rs)['avg_fps'] for rs in self.gpus[g].values())
                           / len(self.gpus[g]))[::-1]          # slowest in front, so tall bars stand behind
            cells = [[(pooled(self.gpus[g][t_])['avg_fps'], color(self.slots[g]),
                       f'<b>{esc(g)}</b><br>{esc(t_)}<br>{pooled(self.gpus[g][t_])["avg_fps"]:.1f} fps avg')
                      if t_ in self.gpus[g] else None for t_ in tests] for g in order]
            t.append('<div class="charts">' + columns3d('3D: average fps, every game and GPU', tests, order, cells,
                                                        'avg fps', 'Slowest GPU in front. Hover a column for its '
                                                        'value; the table above has them all.') + '</div>')
        return page(f'{self.title}: all games', f'{len(names)} GPUs, {len(tests)} game settings',
                    [window('All games x all GPUs', ''.join(t))], self.nav())

    def index_page(self, skipped):
        t = ['<div class="wide"><table><tr><th>GPU</th><th>CPU</th><th>driver</th><th>games</th><th>runs</th>'
             '<th>avg fps</th><th>1% low</th><th>wins</th></tr>']
        for g, tests in self.gpus.items():
            runs = [r for rs in tests.values() for r in rs]
            avg = sum(pooled(rs)['avg_fps'] for rs in tests.values()) / len(tests)
            low = sum(pooled(rs)['low1_fps'] for rs in tests.values()) / len(tests)
            wins = sum(1 for (test, gg, _), (pl, of) in self.rank.items() if gg == g and pl == 1 and of > 1)
            t.append(f'<tr><td class="l"><i style="display:inline-block;width:10px;height:10px;border:1px solid #000;'
                     f'background:{color(self.slots[g])}"></i> <a href="{self.gpu_file(g)}">{esc(g)}</a></td>'
                     f'<td class="l">{esc(distinct(runs, "cpu"))}</td><td class="l">{esc(distinct(runs, "driver"))}</td>'
                     f'<td>{len(tests)}</td><td>{len(runs)}</td><td>{avg:.1f}</td><td>{low:.1f}</td><td>{wins}</td></tr>')
        t.append('</table></div><p class="muted">avg fps / 1% low = mean over the games that GPU ran (different game '
                 'lists are not comparable: see each game page); wins = games and settings where it was fastest.</p>')
        games = ['<div class="wide"><table><tr><th>game</th><th>configurations</th><th>runs</th><th>fastest</th>'
                 '<th>avg fps</th></tr>']
        for game, runs in self.games.items():
            cfgs = self.configs(runs)
            bl, _, brs = max(cfgs, key=lambda c: pooled(c[2])['avg_fps'])
            games.append(f'<tr><td class="l"><a href="{self.game_file(game)}">{esc(game)}</a></td><td>{len(cfgs)}</td>'
                         f'<td>{len(runs)}</td><td class="l">{esc(bl)}</td><td class="top">{pooled(brs)["avg_fps"]:.1f}</td></tr>')
        games.append('</table></div>')
        hello = ('<table style="border:0;background:none;font:inherit"><tr><td style="border:0">'
                 '<img src="90s/vee.gif" width="80" alt="Vee, the FRAMELOG mascot"></td><td class="l" style="border:0">'
                 f'Welcome to the shootout. <b>{len(self.gpus)}</b> graphics card(s), <b>{len(self.games)}</b> game(s), '
                 f'<b>{len(self.runs)}</b> run(s), every frame timed by FRAMELOG on the game PC and logged here by '
                 'fllog.py. Pick a game to see the cards side by side, or a card for its summary.<br>'
                 '<a class="btn" href="shootout.csv">shootout.csv</a> <a class="btn" href="shootout.json">shootout.json</a>'
                 + (' <a class="btn" href="compare.html">all games table</a>' if len(self.gpus) > 1 else '')
                 + '</td></tr></table>')
        wins = [window('Welcome', hello), window('The graphics cards', ''.join(t)), window('The games', ''.join(games))]
        if skipped:
            wins.append(window('Skipped files', '<ul class="note">' + ''.join(f'<li>{esc(s)}</li>' for s in skipped) + '</ul>'))
        return page(self.title, 'frame times from real retro PCs, one game at a time', wins, self.nav())

    # --- exports
    def export_rows(self):
        out = []
        for r in self.runs:
            row = {'run': r.id, 'file': r.name, 'page': r.id + '.html'}
            row.update({k: r.meta.get(k, '') for k in EXPORT_KEYS})
            row['gpu'], row['game'] = r.gpu, r.game
            row.update({k: round(r.stats[k], 3) if isinstance(r.stats[k], float) else r.stats[k] for k in STAT_KEYS})
            out.append(row)
        return out

    def export_csv(self):
        rows = self.export_rows()
        f = io.StringIO()
        w = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator='\n')
        w.writeheader()
        w.writerows(rows)
        return f.getvalue()

    def export_json(self):
        runs = []
        for r, row in zip(self.runs, self.export_rows()):
            runs.append(dict(row, meta=r.meta))
        games = []
        for game, rs in self.games.items():
            cfgs = []
            for lab, _, crs in self.configs(rs):
                s = pooled(crs)
                c = crs[0]
                cfgs.append({'label': lab, 'gpu': c.gpu, 'cpu': c.cpu, 'res': c.res, 'depth': c.depth,
                             'runs': [x.id for x in crs],
                             'stats': {k: round(s[k], 3) if isinstance(s[k], float) else s[k] for k in STAT_KEYS}})
            games.append({'game': game, 'page': self.game_file(game), 'configs': cfgs})
        return json.dumps({'title': self.title, 'generator': 'serial-bench flreport.py', 'runs': runs,
                           'games': games}, indent=1) + '\n'


def build(folders, out, title='Retro GPU Shootout', skip=0.0, wheres=(), log=None, defaults=None, three_d=False):
    """write the report; returns the list of written page/export names (art and CSV copies not listed)"""
    skipped = []

    def warn(s):
        skipped.append(s)
        if log:
            log(s)
    runs = load_runs(find_csvs(folders), skip, wheres, warn, defaults)
    if not runs:
        raise SystemExit('flreport: no runs with frames found')
    rep = Report(runs, title, three_d)
    os.makedirs(os.path.join(out, 'csv'), exist_ok=True)
    os.makedirs(os.path.join(out, '90s'), exist_ok=True)
    for a in ART:
        src = next((os.path.join(d, a) for d in ART_DIRS if os.path.exists(os.path.join(d, a))), None)
        if src and os.path.abspath(src) != os.path.abspath(os.path.join(out, '90s', a)):
            shutil.copyfile(src, os.path.join(out, '90s', a))
    for r in runs:
        shutil.copyfile(r.path, os.path.join(out, 'csv', r.id + '.csv'))
    files = {'index.html': rep.index_page(skipped)}
    if len(rep.gpus) > 1:
        files['compare.html'] = rep.compare_page()
    for game, rs in rep.games.items():
        files[rep.game_file(game)] = rep.game_page(game, rs)
    for g, tests in rep.gpus.items():
        files[rep.gpu_file(g)] = rep.gpu_page(g, tests)
    for r in runs:
        files[r.id + '.html'] = rep.run_page(r)
    files['shootout.csv'] = rep.export_csv()
    files['shootout.json'] = rep.export_json()
    for name, text in files.items():
        with open(os.path.join(out, name), 'w', encoding='utf-8') as f:
            f.write(text)
    return list(files)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('folder', nargs='+', help='folders (searched recursively) or CSV files')
    ap.add_argument('-o', '--out', default='report')
    ap.add_argument('--title', default='Retro GPU Shootout')
    ap.add_argument('--skip', type=float, default=0, help='drop the first S seconds of every run')
    ap.add_argument('--where', action='append', default=[], metavar='KEY=VALUE', help='only runs with this metadata')
    ap.add_argument('--3d', dest='three_d', action='store_true',
                    help='also draw 3D charts: columns and a frame-time waterfall on game pages, a column matrix on compare.html')
    ap.add_argument('--default', action='append', default=[], metavar='KEY=VALUE',
                    help='metadata for CSVs that lack it (older logs), e.g. --default gpu="S3 Trio64"')
    a = ap.parse_args()
    defaults = {}
    for d in a.default:
        k, _, v = d.partition('=')
        defaults[flmeta.norm_key(k)] = flmeta.clean(v)
    files = build(a.folder, a.out, a.title, a.skip, a.where, log=lambda s: print(s, file=sys.stderr),
                  defaults=defaults, three_d=a.three_d)
    for f in files:
        print(os.path.join(a.out, f))
    return 0


if __name__ == '__main__':
    sys.exit(main())
