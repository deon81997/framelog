#!/usr/bin/env python3
"""flstats.py - frame-time stats and graphs from fllog.py CSV files.

  flstats.py run.csv [more.csv ...] [--png graph.png] [--skip S]
             [--label-by gpu,res] [--group-by gpu[,game]] [--where key=value ...]

One row per file: frames, duration, average fps, min/max frame time, 1% and 0.1% lows.
Lows = fps at the 99th / 99.9th percentile frame time (the slowest 1% / 0.1% of frames).
--png draws frame time over time (y-axis capped, see --ymax) for every file (multi-machine comparison) plus a sorted frame-time curve.
--skip drops the first S seconds (loading, menus).
--label-by names each run by its metadata (default: label, else game gpu res, else file name).
--group-by adds a table per group (e.g. per GPU): runs, pooled frames, fps and lows over all its runs.
--where keeps only runs whose metadata matches (case-insensitive, repeatable)."""
import argparse
import os
import sys

import flmeta


def load(path):
    meta, rows = {}, []
    with open(path) as f:
        lines = f.readlines()
    for line in lines:
        line = line.strip()
        if line.startswith('#'):
            k, _, v = line[1:].strip().partition('=')
            meta[k] = v
        elif line and not line.startswith('frame'):
            n, t, ft = line.split(',')
            rows.append((int(n), float(t), float(ft)))
    return meta, rows


def pct(sorted_vals, p):
    """nearest-rank percentile of an ascending list"""
    if not sorted_vals:
        return float('nan')
    k = max(0, min(len(sorted_vals) - 1, int(round(p / 100.0 * len(sorted_vals) + 0.5)) - 1))
    return sorted_vals[k]


def stats(rows):
    ft = sorted(r[2] for r in rows)
    if not ft:
        return None
    dur = sum(ft)
    return {
        'frames': len(ft), 'seconds': dur / 1000.0, 'avg_fps': len(ft) * 1000.0 / dur,
        'avg_ms': dur / len(ft), 'min_ms': ft[0], 'max_ms': ft[-1],
        'low1_fps': 1000.0 / pct(ft, 99), 'low01_fps': 1000.0 / pct(ft, 99.9),
    }


def keys_arg(s):
    return [flmeta.norm_key(k) for k in s.split(',') if k.strip()] if s else []


def matches(meta, wheres):
    for w in wheres:
        k, _, v = w.partition('=')
        if meta.get(flmeta.norm_key(k), '').lower() != v.strip().lower():
            return False
    return True


def run_name(meta, path, label_by):
    return flmeta.describe(meta, label_by, default=os.path.basename(path))


def groups(runs, group_by):
    """runs = [(meta, rows)] -> [(key tuple, [runs])] sorted by key"""
    out = {}
    for meta, rows in runs:
        out.setdefault(tuple(meta.get(k, '') or '?' for k in group_by), []).append((meta, rows))
    return sorted(out.items())


HEAD = f"{'run':24} {'frames':>7} {'sec':>7} {'avg fps':>8} {'avg ms':>7} {'min ms':>7} {'max ms':>8} {'1% low':>7} {'0.1% low':>8}"


def fmt(name, s, last):
    if not s:
        return f"{name[:24]:24} no frames"
    return (f"{name[:24]:24} {s['frames']:7d} {s['seconds']:7.1f} {s['avg_fps']:8.2f} {s['avg_ms']:7.2f} {s['min_ms']:7.2f} "
            f"{s['max_ms']:8.2f} {s['low1_fps']:7.2f} {s['low01_fps']:8.2f} {last:>5}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('csv', nargs='+')
    ap.add_argument('--png')
    ap.add_argument('--skip', type=float, default=0)
    ap.add_argument('--ymax', type=float, default=0, help='frame-time axis limit in ms (default: 4x the 99th percentile, spikes above are clipped)')
    ap.add_argument('--label-by', type=keys_arg, default=[], metavar='KEYS', help='comma list of metadata keys naming each run')
    ap.add_argument('--group-by', type=keys_arg, default=[], metavar='KEYS', help='comma list of metadata keys to pool runs by')
    ap.add_argument('--where', action='append', default=[], metavar='KEY=VALUE', help='only runs with this metadata value')
    a = ap.parse_args()
    loaded = []
    for p in a.csv:
        meta, rows = load(p)
        if matches(meta, a.where):
            loaded.append((meta, [r for r in rows if r[1] >= a.skip * 1000.0], p))
    if not loaded:
        print("no runs match")
        return 1
    runs = []
    print(HEAD + f" {'lost':>5}")
    for meta, rows, p in loaded:
        name = run_name(meta, p, a.label_by)
        runs.append((name, rows))
        print(fmt(name, stats(rows), meta.get('lost', '?')))
    if a.group_by:
        print()
        print(HEAD.replace('run     ', 'group   ', 1) + f" {'runs':>5}")
        for key, members in groups([(m, r) for m, r, _ in loaded], a.group_by):
            pooled = [r for _, rows in members for r in rows]
            print(fmt(' '.join(key), stats(pooled), len(members)))
    if a.png:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(11, 7))
        for name, rows in runs:
            ax1.plot([r[1] / 1000.0 for r in rows], [r[2] for r in rows], lw=0.8, label=name, drawstyle='steps-pre')
            ft = sorted((r[2] for r in rows), reverse=True)
            ax2.plot([100.0 * i / max(1, len(ft) - 1) for i in range(len(ft))], ft, lw=1, label=name)
        ym = a.ymax or 4 * max((pct(sorted(r[2] for r in rows), 99) for _, rows in runs if rows), default=0) or None
        if ym:
            ax1.set_ylim(0, ym); ax2.set_ylim(0, ym)
        ax1.set_xlabel('time (s)'); ax1.set_ylabel('frame time (ms)'); ax1.set_title('Frame time')
        ax2.set_xlabel('% of frames (slowest first)'); ax2.set_ylabel('frame time (ms)'); ax2.set_xscale('symlog', linthresh=1); ax2.set_xlim(0, 100)
        for ax in (ax1, ax2):
            ax.grid(alpha=0.3)
            ax.legend(loc='upper right', fontsize=8)
        fig.tight_layout()
        fig.savefig(a.png, dpi=110)
        print(f"graph -> {a.png}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
