@echo off
C:
cd \UT\System
if exist Running.ini del Running.ini
start /w UnrealTournament.exe DM-TurbineDEMO.unr -nosound
copy UnrealTournament.log D:\UT0.LOG > nul
start D:\FRAMELOG.EXE /COM:1 /LOG /Q
choice /t:y,8 /n > nul
cd \UT\System
if exist Running.ini del Running.ini
start /w UnrealTournament.exe DM-TurbineDEMO.unr -nosound
copy UnrealTournament.log D:\UT1.LOG > nul
choice /t:y,3 /n > nul
D:\FRAMELOG.EXE /STOP
choice /t:y,5 /n > nul
C:\WINDOWS\RUNDLL32.EXE USER.EXE,ExitWindows
