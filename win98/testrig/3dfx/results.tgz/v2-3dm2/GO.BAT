@echo off
start D:\FRAMELOG.EXE /COM:1 /LOG /Q
choice /t:y,8 /n > nul
C:
cd \3DMARK99
start 3dmark.exe
