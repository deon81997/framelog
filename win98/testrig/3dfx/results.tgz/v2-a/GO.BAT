@echo off
C:
cd \QUAKE2
start /w quake2.exe +set vid_ref gl +set gl_driver 3dfxgl +set logfile 2 +set vid_fullscreen 1 +set gl_mode 3 +set sw_mode 3 +timedemo 1 +alias fin "killserver; quit" +alias go "demomap q2demo1.dm2; set nextserver fin" +go
copy baseq2\qconsole.log D:\Q2mgl0.LOG > nul
cd \QUAKE2
start /w quake2.exe +set vid_ref gl +set gl_driver 3dfxvgl +set logfile 2 +set vid_fullscreen 1 +set gl_mode 3 +set sw_mode 3 +timedemo 1 +alias fin "killserver; quit" +alias go "demomap q2demo1.dm2; set nextserver fin" +go
copy baseq2\qconsole.log D:\Q2icd0.LOG > nul
cd \QUAKE2
start /w quake2.exe +set vid_ref soft +set gl_driver 3dfxgl +set logfile 2 +set vid_fullscreen 1 +set gl_mode 3 +set sw_mode 3 +timedemo 1 +alias fin "killserver; quit" +alias go "demomap q2demo1.dm2; set nextserver fin" +go
copy baseq2\qconsole.log D:\Q2soft0.LOG > nul
cd \EXPEND
if exist timedemo.txt del timedemo.txt
start /w go.exe -timedemo
copy timedemo.txt D:\EXP0.TXT > nul
cd \INCOMING
if exist fps.txt del fps.txt
start /w gameindex.exe -secondary -nosound
copy fps.txt D:\INC0.TXT > nul
start D:\FRAMELOG.EXE /COM:1 /LOG /Q
choice /t:y,8 /n > nul
cd \QUAKE2
start /w quake2.exe +set vid_ref gl +set gl_driver 3dfxgl +set logfile 2 +set vid_fullscreen 1 +set gl_mode 3 +set sw_mode 3 +timedemo 1 +alias fin "killserver; quit" +alias go "demomap q2demo1.dm2; set nextserver fin" +go
copy baseq2\qconsole.log D:\Q2mgl1.LOG > nul
cd \QUAKE2
start /w quake2.exe +set vid_ref gl +set gl_driver 3dfxvgl +set logfile 2 +set vid_fullscreen 1 +set gl_mode 3 +set sw_mode 3 +timedemo 1 +alias fin "killserver; quit" +alias go "demomap q2demo1.dm2; set nextserver fin" +go
copy baseq2\qconsole.log D:\Q2icd1.LOG > nul
cd \QUAKE2
start /w quake2.exe +set vid_ref soft +set gl_driver 3dfxgl +set logfile 2 +set vid_fullscreen 1 +set gl_mode 3 +set sw_mode 3 +timedemo 1 +alias fin "killserver; quit" +alias go "demomap q2demo1.dm2; set nextserver fin" +go
copy baseq2\qconsole.log D:\Q2soft1.LOG > nul
cd \EXPEND
if exist timedemo.txt del timedemo.txt
start /w go.exe -timedemo
copy timedemo.txt D:\EXP1.TXT > nul
cd \INCOMING
if exist fps.txt del fps.txt
start /w gameindex.exe -secondary -nosound
copy fps.txt D:\INC1.TXT > nul
choice /t:y,3 /n > nul
D:\FRAMELOG.EXE /STOP
choice /t:y,5 /n > nul
C:\WINDOWS\RUNDLL32.EXE USER.EXE,ExitWindows
